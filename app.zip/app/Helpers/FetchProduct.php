<?php namespace App\Helpers;
use Config,Log;

ini_set('arg_separator.output', '&'); // for http_build_query
class FetchProduct {
	public $key = AMAZON_API_KEY;
	public $secret = AMAZON_API_SECRET_KEY;
	public $tag = AMAZON_ASSOCIATE_TAG;
	public $host = 'webservices.amazon.';
	
	private $path = '/onca/xml';

	function sign($params,$country_code){
		uksort($params, 'strnatcmp');
		foreach ($params as $key => &$value)
		$value = $key . '=' . rawurlencode($value);

		return base64_encode(hash_hmac('sha256', implode("\n", array('GET', $this->host, $this->path, implode('&', $params))), $this->secret, TRUE));
	}

	function lookup($asin,$country_code,$extension) {

		if ($country_code != '' and !empty($country_code)) {
			$this->host = $this->host.strtolower($country_code->country_id);
			$this->tag = $country_code->affiliate_id;

			if ($country_code->access_key != '') {
				$this->key = $country_code->access_key;
			}

			if ($country_code->secret_key != '') {
				$this->secret = $country_code->secret_key;
			}

		}else{
			$default_value = Config::get('DefaultValues');
			
			if(array_key_exists($extension, $default_value)){
				$values = $default_value[$extension];
				$this->key = $values['API_KEY'];
				$this->secret = $values['API_SECRET'];
				$this->tag = $values['API_AFFILIATE_LINK'];
				$this->host = $this->host.$extension;
			}else{
				$this->host = $this->host.'com';
			}
		}
		
		$params = array(
			'Service' => 'AWSECommerceService',
			'Version' => '2009-10-01',
			'Timestamp' => date(DATE_ISO8601),
			'AWSAccessKeyId' => $this->key,
			'AssociateTag' => $this->tag,
			'Operation' => 'ItemLookup',
			'IdType' => 'ASIN',
			'ItemId' => $asin,
			'ResponseGroup' => 'Large',
		);
	
		$params['Signature'] = $this->sign($params,$country_code);
		$xml = simplexml_load_file('https://' . $this->host . $this->path . '?' . http_build_query($params));
		$xml = json_encode($xml);
		$xml = json_decode($xml,true);
		
		return $xml;
	}
}
?>