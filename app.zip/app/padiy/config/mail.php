<?php

return array(
  "driver" => "smtp",
  "host" => "smtp.mailtrap.io",
  "port" => 2525,
  "from" => array(
      "address" => "from@example.com",
      "name" => "Example"
  ),
  "username" => "c4cff1a4ba2ed8",
  "password" => "acd35195edaeea",
  "sendmail" => "/usr/sbin/sendmail -bs",
  "pretend" => false
);
