<?php
define('MATERIAL_API', 'https://raymondcentral.com/DIYAPI/api/Material/GetAll');
define('TEMP_DOTNET_ORDER','https://raymondcentral.com/DIYAPI/api/TempOrder/CreateTempOrder');
define('CONFIRM_ORDER','https://raymondcentral.com/DIYAPI/api/Orders/CreateOrder');
define('MEASUREMENT_ORDER','https://raymondcentral.com/DIYAPI/api/Measurement/InsertMeasurement');
define('CONSUMPTION', 'https://raymondcentral.com/DIYAPI/api/Consumption');
define('CHECK_INVENTORY', 'https://raymondcentral.com/DIYAPI/api/Material/GetByFabric?fabricCode=');