<?php

return [
	'api_key' 	=> '4e8437ace0fcd29af1a18e82514df25d',
	'password' 	=> '6c037deddfc587e546f9ce200a515169',
	'secret' 	=> '33886cb9cd6ea66eb560e407ae86ca5e',
	'domain' 	=> 'parkavenue.myshopify.com',
	'product_type' => ['Fabric_Shirt']
];