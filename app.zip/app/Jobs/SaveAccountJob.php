<?php

namespace App\Jobs;

use App\Models\Account;
use Illuminate\Http\Request;

class SaveAccountJob
{

    protected $request_account_details;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($request_account_details)
    {
       $this->request_account_details = $request_account_details;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(Request $request)
    {
        $request_account_details = $this->request_account_details;

        $store_id = $request_account_details['store_id'];

        $save_account_details = Account::firstOrNew(['store_id'=>$store_id]);
        
        $save_account_details->fill($request_account_details['account_details']);
        $save_account_details->store_id = $store_id;

        $save_account_details->save();
    }
}
