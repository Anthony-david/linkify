<?php

namespace App\Jobs;

use Illuminate\Http\Request;
use App\Models\AutoSync;

class SaveAutoSyncJob
{

    protected $request_auto_sync_action_details;

    public function __construct($request_auto_sync_action_details)
    {
        $this->request_auto_sync_action_details = $request_auto_sync_action_details;
    }

    public function handle(Request $request)
    {
        $request_auto_sync_action_details = $this->request_auto_sync_action_details;
        
        $save_auto_sync_details = AutoSync::firstOrCreate(['store_id'=>$request_auto_sync_action_details['store_id']]);
        $save_auto_sync_details->fill($request_auto_sync_action_details['action_credentials_details']);
        $save_auto_sync_details->store_id = $request_auto_sync_action_details['store_id'];
        $save_auto_sync_details->save();
    }
}
