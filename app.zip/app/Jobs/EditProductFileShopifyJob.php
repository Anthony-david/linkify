<?php

namespace App\Jobs;

use Shopify;

class EditProductFileShopifyJob
{
    protected $shop_name;
    protected $accesstoken;

/**
* Create a new job instance.
*
* @return void
*/
public function __construct($shop_name,$accesstoken)
{
    $this->shop_name = $shop_name;
    $this->accesstoken = $accesstoken;
}

/**
* Execute the job.
*
* @return void
*/
public function handle()
{
    $shop_name = $this->shop_name;
    $accesstoken = $this->accesstoken;

    $shop_auth = Shopify::retrieve($shop_name, $accesstoken);

    $themes = $shop_auth->get('themes');

    foreach ($themes['themes'] as $key => $single_theme) {
        $asset = $shop_auth->get('themes/'.$single_theme['id'].'/assets');

        $liquid = $shop_auth->get('themes/'.$single_theme['id'].'/assets?asset[key]=sections/product-template.liquid&theme_id='.$single_theme['id']);

        if (isset($liquid['asset']) and count($liquid['asset'])) {
         
            $content = $liquid['asset']['value'];

            $liquid_array = explode(PHP_EOL, $content);

            $done = 0;

            foreach ($liquid_array as $single_key => $single_line) {
                
                if (trim($single_line) == "{% form 'product', product, class:form_classes %}") {
                    $single_line = $single_line.'{% include "linkify"%}';
                    $liquid_array[$single_key] = $single_line;
                    $done = 1;
                }

                if (trim($single_line) == "{% if section.settings.enable_payment_button %}" and $done == 0) {
                    $single_line = '{% include "linkify"%}'.$single_line;
                    $liquid_array[$single_key] = $single_line;
                    $done = 1;
                }
            }
            
            $liquid_array = implode("\n", $liquid_array);
         
            $modify_data = [
                'key' => 'sections/product-template.liquid',
                'value' => $liquid_array
            ];

            $asset_details['asset'] = $modify_data;

            $modifiy_templete = $shop_auth->modify('themes/'.$single_theme['id'].'/assets',$asset_details);
        }
    }
}
}
