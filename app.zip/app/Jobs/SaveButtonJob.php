<?php

namespace App\Jobs;

use Illuminate\Http\Request;
use App\Models\Button;

class SaveButtonJob
{

    protected $request_buttons_details;

    public function __construct($request_buttons_details)
    {
        $this->request_buttons_details = $request_buttons_details;
    }

    public function handle(Request $request)
    {
        $request_buttons_details = $this->request_buttons_details;
        $store_id = $request_buttons_details['store_id'];
        $save_button_details = Button::firstOrNew(['store_id'=>$store_id]);
        $save_button_details->fill($request_buttons_details['buttons_details']);
        $save_button_details->store_id = $store_id;
        $save_button_details->save();
    }
}
