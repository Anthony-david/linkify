<?php

namespace App\Jobs;

use Illuminate\Http\Request;
use App\Models\AmazonTag;

class SaveAmazonTagJob
{

    protected $request_amazontag_details;

    public function __construct($request_amazontag_details)
    {
        $this->request_amazontag_details = $request_amazontag_details;
    }

    public function handle(Request $request)
    {
        $request_amazontag_details = $this->request_amazontag_details;
 
        $store_id = $request_amazontag_details['store_id'];
        $country_id = $request_amazontag_details['amazontag_details']['country_id'];
        $save_amazon_details = AmazonTag::firstOrNew(['store_id'=>$store_id,'country_id'=>$country_id]);
        $save_amazon_details->fill($request_amazontag_details['amazontag_details']);
        $save_amazon_details->store_id = $store_id;
        $save_amazon_details->save();
    }
}
