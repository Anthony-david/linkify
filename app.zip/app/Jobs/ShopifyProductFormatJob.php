<?php

namespace App\Jobs;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\DefaultValue;
use App\Models\AmazonTag;
use Shopify;
use App\Models\Store;
use App\Models\MarkupPricing;
use Log;
use Config;
use GuzzleHttp\Exception\RequestException;

class ShopifyProductFormatJob
{

    protected $id;
    protected $extension;

    public function __construct($id,$extension)
    {
        $this->id = $id;
        $this->extension = $extension;
    }

    public function handle(Request $request)
    {
        try {
            
            $id = $this->id;
            $extension = $this->extension;
        
            $multiply_price = 1;

            $default_value_array = Config::get('DefaultValues');

            $product_data = Product::where('id',$id)->first()->toArray();

            $shopify_product_id = $product_data['shopify_product_id'];
            $shopify_id = $product_data['shopify_variant_id'];
            $store_id = $product_data['store_id'];

            $shop_details = Store::where('id',$store_id)->first();

            $amazon_tag = AmazonTag::where('store_id',$store_id)
                                        ->first();

            $default_value = DefaultValue::where('store_id',$store_id)->first();
            
            if(array_key_exists($extension, $default_value_array)){
                
                $values = $default_value_array[$extension];
                $multiply_price_main = $values['CONVERSION_RATE'];
             
                if($default_value['currency'] != null)
                {
                    $country_id = $default_value['currency'];
                }
                else
                {
                    $country_id = AMAZON_COUNTRY;
                }

                // if ($amazon_tag != '' and $amazon_tag->country_id != '') {
                //     $country_id = $amazon_tag->country_id;
                // }
               
                if (isset($multiply_price_main[$country_id]) and $multiply_price_main[$country_id] != '') {
                    $multiply_price = $multiply_price_main[$country_id];
                }
            }

            $markup_price = MarkupPricing::where('store_id',$store_id)->first();
            
            $medium_images = [];
            $product_variants_modified = [];
            $variant_price = 0;
            $compair_price = 0;

            if(array_key_exists('other_details', $product_data))
            {   
                if(array_key_exists('Items', $product_data['other_details']))
                {
                    if(array_key_exists('Item', $product_data['other_details']['Items']))
                    {

                        if(array_key_exists('ItemAttributes', $product_data['other_details']['Items']['Item']))
                        {
                            $product_attribute = $product_data['other_details']['Items']['Item']['ItemAttributes'];
                 
                            if (isset($product_attribute['ItemDimensions'])){
                                if (isset($product_attribute['ItemDimensions']['Weight'])) {
                                    $product_variants_modified['weight'] = $product_attribute['ItemDimensions']['Weight'];
                                }
                            }

                            if (isset($product_attribute['ListPrice'])) {
                                $price_main = $product_attribute['ListPrice'];

                                if (isset($price_main['Amount'])) {
                                    $variant_price = Product::PriceConverter($price_main['Amount'],100);
                                    $compair_price = $variant_price;
                                }
                            }

                            if(array_key_exists('ProductTypeName', $product_attribute))
                            {
                                $product_data['product_type'] = $product_attribute['ProductTypeName'];
                            }
                            else
                            {
                                if($default_value != null)
                                {
                                    $product_data['product_type'] = $default_value['product_type'];      
                                }
                            }
                            if($default_value['auto_fill'] == 1)
                            {
                                if(array_key_exists('Publisher', $product_attribute))
                                {
                                    $product_data['vendor'] = $product_attribute['Publisher']; 
                                }
                            }
                            else
                            {
                                $product_data['vendor'] = $default_value['vendor']; 
                            }
                        }

                        if (array_key_exists('OfferSummary', $product_data['other_details']['Items']['Item'])) {
                            $offer_summary = $product_data['other_details']['Items']['Item']['OfferSummary'];

                            if (isset($offer_summary['LowestNewPrice'])) {
                                $amount_offer = $offer_summary['LowestNewPrice'];

                                if (isset($amount_offer['Amount'])) {
                                    $variant_price = Product::PriceConverter($amount_offer['Amount'],100);
                                }
                            }
                        }

                        if(array_key_exists('ImageSets',$product_data['other_details']['Items']['Item']))
                        {
                            if(array_key_exists('ImageSet',$product_data['other_details']['Items']['Item']['ImageSets']))
                            {
                                if(array_key_exists('ImageSet', $product_data['other_details']['Items']['Item']['ImageSets']))
                                {
                                    $array_val = $product_data['other_details']['Items']['Item']['ImageSets']['ImageSet'];
                                    
                                    foreach ($array_val as $key => $single_value) {   
                                        if (array_key_exists('LargeImage',$single_value)) {
                                           $medium_images[$key]['src'] = $single_value['LargeImage']['URL'];
                                        }
                                    }
                                }    
                            }
                        }
                    }
                }
            }

            $feature = [];

            if (isset($product_attribute['Feature'])) {
                $feature = $product_attribute['Feature'];

                unset($product_attribute['Feature']);
            }

            $feature_view = view('admin.product.feature_list',compact('product_attribute','feature'))->render();

            $product_data['body_html'] = $feature_view;
            
            $product_data['multi_images'] = array_reverse($medium_images);
            
            $shopify_price = $variant_price;
            $compare_price = $compair_price;
            
            if ($markup_price != null and $markup_price->count() and $markup_price->new_product != 1) {
                
                if (isset($markup_price->amazon_markup_price) and isset($markup_price->amazon_multiplier_price)) {
                    $new_a_price = $markup_price->amazon_multiplier_price;

                    if ($new_a_price == 0 or $new_s_price = 0.00) {
                        $new_a_price = 1;
                    }
                    $shopify_price = ($variant_price * $new_a_price) + $markup_price->amazon_markup_price;
                }

                if (isset($markup_price->cents_price)) {
                    $shopify_price = $shopify_price + ($markup_price->cents_price / 100);
                }

                if (isset($markup_price->shopify_markup_price) and isset($markup_price->shopify_multiplier_price)) {

                    $new_s_price = $markup_price->shopify_multiplier_price;
                    
                    if ($new_s_price == 0 or $new_s_price == 0.00) {
                        $new_s_price = 1;
                    }
                    
                    $compare_price = ($compair_price * $new_s_price) + $markup_price->shopify_markup_price;
                }

                if (isset($markup_price->cents_comp_price)) {
                    $compare_price = $compare_price + ($markup_price->cents_comp_price / 100);
                }
            }
            
            $shopify_price = $shopify_price * $multiply_price;

            $product_variants_modified['price'] = $shopify_price;

            $compare_price = $compare_price * $multiply_price;

            if ($compare_price == 0) {
                $compare_price = $shopify_price;
            }

            $product_variants_modified['compare_at_price'] = $compare_price;
            $product_variants_modified['sku'] = $product_data['asin'];
            $product_variants_modified['title'] = $product_data['title'];
            // $product_variants_modified['option1'] = $product_data['title'];
            $product_variants_modified['weight_unit'] = 'g';

            if (isset($default_value->quantity) and $default_value->quantity != 0) {
                $product_variants_modified['inventory_quantity'] = $default_value->quantity;
                $product_variants_modified['inventory_management'] = 'shopify';
            }
           
            $product_data = Product::ProductDataModifyShopify($product_data,$store_id,$extension,$product_variants_modified);
         
            if (isset($default_value->product_type) and $default_value->product_type != '') {
                $product_data['product']['product_type'] = $default_value->product_type;
            }

            if (isset($default_value->vendor) and $default_value->vendor != '' and $default_value->auto_fill == 1) {
                $product_data['product']['vendor'] = $default_value->vendor;
            }

            if (isset($default_value->tag) and count($default_value->tag)) {
                $product_data['product']['tags'] = implode(',', $default_value->tag);
            }

            if (isset($default_value->template_suffix) and $default_value->template_suffix != '') {
                $product_data['product']['template_suffix'] = $default_value->template_suffix;
            }

            if (isset($default_value->store) and $default_value->store == 0) {
                $product_data['product']['published'] = false;
            }

            if ($shopify_price == 0) {
                $product_data['product']['published'] = false;
            }
            
            $shop_auth = Shopify::retrieve($shop_details->shop, $shop_details->token);
            $product_count = [];

            try {
                if ($shopify_id == '') {
                    $product_count = $shop_auth->create('products',$product_data);
                }else{

                    $published = true;

                    if ($shopify_price == 0) {
                        $published = false;
                    }

                    $product_update_array = [
                        'id' => $shopify_product_id,
                        'published' => $published
                    ];

                    $product_update = $shop_auth->modify('products/'.$shopify_product_id,['product'=>$product_update_array]);
                    
                    $modified_data = [
                        'id' => $shopify_id,
                        'price' => $shopify_price,
                        'compare_at_price' => $compare_price,
                        'body_html' => $feature_view
                    ];
                    
                    Log::info($modified_data);
                    $change_data['variant'] = $modified_data;
                    
                    $product_count = $shop_auth->modify('variants/'.$shopify_id,$change_data);
                }
                
            } catch (RequestException $e) {
                Log::error($e);
            }

            
            if (count($product_count)) {
                if (isset($product_count['product']) and count($product_count['product'])) {
                    $product_details = $product_count['product'];
                    $product_variant = head($product_details['variants']);

                    $save_product = Product::where('id',$id)->first();
                    $save_product->shopify_product_id = $product_details['id'];
                    $save_product->handle = $product_details['handle'];
                    $save_product->price = $shopify_price;
                    $save_product->shopify_details = $product_details;
                    $save_product->shopify_variant_id = $product_variant['id'];
                    $save_product->save();
                }else{
                    $save_product = Product::where('id',$id)->first();
                    $save_product->price = $shopify_price;
                    $save_product->save();
                }
            }
            Log::info(3);
            return $product_data;
        } catch (ShopifyProductFormatJob $e) {
            Log::error($e);
        }
    }
}
