<?php

namespace App\Jobs;

use Shopify;

class UploadFileToShopifyJob
{
    protected $shop_name;
    protected $accesstoken;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($shop_name,$accesstoken)
    {
        $this->shop_name = $shop_name;
        $this->accesstoken = $accesstoken;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $shop_name = $this->shop_name;
        $accesstoken = $this->accesstoken;

        $shop_auth = Shopify::retrieve($shop_name, $accesstoken);

        $themes = $shop_auth->get('themes');
        
        if (isset($themes['themes']) and count($themes['themes'])) {
            foreach ($themes['themes'] as $key => $single_theme) {
                $snippets = 'themes/'.$single_theme['id'].'/assets';

                $snippets_details['asset'] = [
                    'key' => 'snippets/linkify.liquid',
                    'src' => URL_PATH."backend/linkify.liquid"
                ];

                $create_snippets = $shop_auth->modify($snippets,$snippets_details);
            }
        }
    }
}
