<?php

namespace App\Jobs;

use Illuminate\Http\Request;
use App\Models\DefaultValue;

class SaveDefaultValueJob
{

    protected $request_default_values_details;

    public function __construct($request_default_values_details)
    {
        $this->request_default_values_details = $request_default_values_details;
    }

    public function handle(Request $request)
    {
        $request_default_values_details = $this->request_default_values_details;
        
        $store_id = $request_default_values_details['store_id'];
        
        $currency = $request_default_values_details['default_values_details']['currency'];
        
        $tags = [];

        if (isset($request_default_values_details['default_values_details']['tag']) and count($request_default_values_details['default_values_details']['tag'])) {
            $tags = $request_default_values_details['default_values_details']['tag'];
        }
       
        $request_default_values_details['default_values_details']['tag'] = $tags;

        $save_default_value_details = DefaultValue::firstOrNew(['store_id'=>$store_id]);

        $save_default_value_details->fill($request_default_values_details['default_values_details']);
        
        $save_default_value_details->auto_fill = 0;

        if(array_key_exists('auto_fill', $request_default_values_details['default_values_details']))
        {   
            $save_default_value_details->auto_fill = $request_default_values_details['default_values_details']['auto_fill'];
        }
        $save_default_value_details->store_id = $store_id;
        $save_default_value_details->save();
    }
}
