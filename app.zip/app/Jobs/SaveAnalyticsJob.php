<?php

namespace App\Jobs;

use Illuminate\Http\Request;
use App\Models\Analytics;

class SaveAnalyticsJob
{

    protected $request_analytics_details;

    public function __construct($request_analytics_details)
    {
        $this->request_analytics_details = $request_analytics_details;
    }

    public function handle(Request $request)
    {
        $request_analytics_details = $this->request_analytics_details;
        $store_id = $request_analytics_details['store_id'];
        
        $save_analytics_details =  Analytics::firstOrNew(['store_id'=>$store_id]);
        $save_analytics_details->fill($request_analytics_details['analytics_details']);
        $save_analytics_details->store_id = $store_id;
        $save_analytics_details->save();
    }
}