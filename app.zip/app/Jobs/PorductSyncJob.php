<?php

namespace App\Jobs;

use App\Models\Store;
use App\Models\Product;
use App\Jobs\FeatchProductAmazon;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Log;

class PorductSyncJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $product_link;
    protected $store_id;
    protected $extension;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($product_link,$store_id,$extension)
    {
        $this->product_link = $product_link;
        $this->store_id = $store_id;
        $this->extension = $extension;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $product_link = $this->product_link;
        $store_id = $this->store_id;
        $extension = $this->extension;

        dispatch(new FeatchProductAmazon($product_link,$store_id,$extension));
    }
}
