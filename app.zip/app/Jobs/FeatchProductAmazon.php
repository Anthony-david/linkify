<?php
namespace App\Jobs;

use AmazonProduct;
use App\Models\Product;
use App\Models\AmazonTag;
use App\Helpers\FetchProduct;
use App\Jobs\ShopifyProductFormatJob;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Log;

class FeatchProductAmazon
{

    protected $product_link;
    protected $store_id;
    protected $extension;

    use DispatchesJobs;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($product_link,$store_id,$extension)
    {
        $this->product_link = $product_link;
        $this->store_id = $store_id;
        $this->extension = $extension;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try {
            $product_link = $this->product_link;
            $store_id = $this->store_id;
            $extension = $this->extension;
            // $country_code = AmazonTag::where('store_id',$store_id)->first();
            $country_code = "";
               
            Log::info($product_link);

            if ($product_link != '') {
                Log::info($store_id);
                Log::info($product_link);
                // $response = AmazonProduct::item($product_link);
                $api = new FetchProduct;
                $response = $api->lookup($product_link,$country_code,$extension);
               
                if (isset($response['Items']['Item']) and count($response['Items']['Item'])) {
                    
                    $item_details = $response['Items']['Item'];
                   
                    $save_product = Product::firstOrNew(['asin'=>$item_details['ASIN'],'store_id'=>$store_id]);
                    
                    $save_product->store_id = $store_id;
                    $save_product->title = $item_details['ItemAttributes']['Title'];
                    $save_product->slug = str_slug(preg_replace('/[^A-Za-z0-9\-]/', '-',$item_details['ItemAttributes']['Title']));
                    
                    if (isset($item_details['ParentASIN'])) {
                        $save_product->parent_asin = $item_details['ParentASIN'];
                    }

                    if (isset($item_details['ItemAttributes']['Brand'])) {
                        $save_product->brand = $item_details['ItemAttributes']['Brand'];
                    }
                    
                    $save_product->page_url = $item_details['DetailPageURL'];
                    $save_product->medium_image = '';

                    if (isset($item_details['MediumImage']['URL'])) {
                        $save_product->medium_image = $item_details['MediumImage']['URL'];  
                    }

                    $price = 0;

                    if (isset($item_details['ItemAttributes']['ListPrice']['FormattedPrice'])) {
                        $price = $item_details['ItemAttributes']['ListPrice']['FormattedPrice'];
                    }
                    
                    $save_product->price = $price;
                    $save_product->other_details = $response;
                    $save_product->save();

                    $product_id = $save_product->id;
                    Log::info(2);
                    dispatch(new ShopifyProductFormatJob($product_id,$extension));
                }
            }
            
        } catch (Exception $e) {
            Log::error($e);
        }
    }
}