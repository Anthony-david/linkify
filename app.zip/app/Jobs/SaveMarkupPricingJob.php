<?php

namespace App\Jobs;

use Illuminate\Http\Request;
use App\Models\MarkupPricing;

class SaveMarkupPricingJob
{

    protected $request_markup_pricing_details;

    public function __construct($request_markup_pricing_details)
    {
        $this->request_markup_pricing_details = $request_markup_pricing_details;
    }

    public function handle(Request $request)
    {
        $request_markup_pricing_details = $this->request_markup_pricing_details;
        $store_id = $request_markup_pricing_details['store_id'];
        
        $save_markup_pricing_details = MarkupPricing::firstOrNew(['store_id'=>$store_id]);
        $save_markup_pricing_details->fill($request_markup_pricing_details['markup_pricing_details']);
        $save_markup_pricing_details->store_id = $store_id;
        $save_markup_pricing_details->save();
    }
}
