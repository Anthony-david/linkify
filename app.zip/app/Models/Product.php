<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Config;
use App\Models\Button;
use App\Models\AmazonTag;

class Product extends Model {

	protected $table = 'products';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = ['store_id','store','slug','shopify_product_id','shopify_variant_id','title','asin','parent_asin','brand','price','page_url','medium_image','other_details','handle','shopify_details'];

	public function setOtherDetailsAttribute($value) {
		$this->attributes['other_details'] = serialize($value);
	}

	public function getOtherDetailsAttribute($value)
    {
        return unserialize($value);
    }

    public function setShopifyDetailsAttribute($value) {
        $this->attributes['shopify_details'] = serialize($value);
    }

    public function getShopifyDetailsAttribute($value)
    {
        return unserialize($value);
    }

    public static function ProductDataModifyShopify($data_to_modify,$store_id,$extension,$product_variants = null)
    {
        $modified_data = [];
      
        $modified_data['title'] = $data_to_modify['title'] ;
        $modified_data['published'] = true;

        $modified_data['body_html']   = $data_to_modify['body_html'];
        
        $modified_data['product_type']  = $data_to_modify['product_type'];

        // $modified_data['image']  = $data_to_modify['medium_image'];

        $modified_data['images'] = $data_to_modify['multi_images'];
        
        $product_id = $data_to_modify['id'];
        
        if (isset($data_to_modify['tags'])) {
            $modified_data['tags'] = $data_to_modify['tags'];
        }

        if ($product_variants != null) {
            $modified_data['variants'][] = $product_variants;
        }

        $button_details = Button::where('store_id',$store_id)->first();
        $associate_tag = AmazonTag::where('store_id',$store_id)->where('country_id',$extension)->first();
        
        $meta_field = self::metaFieldCreate($data_to_modify,$button_details,$associate_tag,$extension);

        $modified_data['metafields'] = $meta_field;

        $product_modified_data['product'] = $modified_data;
        
        return $product_modified_data;
    }

    public static function PriceConverter($price,$con_rate){
        return $price / $con_rate;
    }
    
    public static function metaFieldCreate($meta_field,$button_details,$affiliate_id,$extension){
        $page_url = '';
        
        if (isset($meta_field['page_url'])) {
            $page_url = $meta_field['page_url'];
            $page_url = strtok($page_url, "?");

        }

        $meta_field_1 = [
            'key' => 'linkify-url',
            "value"=> $page_url,
            "value_type"=> "string",
            "namespace"=> "global"
        ];

        $meta_field_2 = [
            'key' => 'linkify-tag',
            "value"=> 'linkify-affiliate',
            "value_type"=> "string",
            "namespace"=> "global"
        ];

        $meta_field_3 = [
            'key' => 'linkify-region',
            "value"=> $extension,
            "value_type"=> "string",
            "namespace"=> "global"
        ];

        $affiliate_id_set = '';

        if ($affiliate_id != '' and $affiliate_id->affiliate_id != '') {
            $affiliate_id_set = $affiliate_id->affiliate_id;
        }

        $meta_field_4 = [
            'key' => 'linkify-affiliate-tag',
            "value"=> $affiliate_id_set,
            "value_type"=> "string",
            "namespace"=> "global"
        ];

        $button_text = 'View On Amazon';

        if ($button_details != '' and $button_details->button_text != '') {
            $button_text = $button_details->button_text;
        }

        $meta_field_5 = [
            'key' => 'linkify-text',
            "value"=> $button_text,
            "value_type"=> "string",
            "namespace"=> "global"
        ];

        return [$meta_field_1,$meta_field_2,$meta_field_3,$meta_field_4,$meta_field_5];
    }
}
