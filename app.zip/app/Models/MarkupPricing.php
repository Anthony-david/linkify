<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarkupPricing extends Model
{
    protected $table = "markup_pricing";

    protected $fillable = ['id','store_id','new_product','amazon_multiplier_price','amazon_markup_price','shopify_multiplier_price','shopify_markup_price','cents_price','cents_comp_price'];

    public function setCentsPriceAttribute($value) {
		$this->attributes['cents_price'] = $value / 100;
	}

	public function getCentsPriceAttribute($value) {
		return $value * 100;
	}

	public function setCentsCompPriceAttribute($value) {
		$this->attributes['cents_comp_price'] = $value / 100;
	}

	public function getCentsCompPriceAttribute($value) {
		return $value * 100;
	}
}
