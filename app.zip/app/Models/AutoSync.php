<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AutoSync extends Model
{
    protected $table = 'auto_sync';

    protected $fillable = ['id', 'store_id', 'auto_sync_action', 'product_price', 'product_stock', 'discontinue_product'];
}
