<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DefaultValue extends Model
{
    protected $table = 'default_values';
 
	protected $fillable = ['id','store','product_type','vendor','tag','template_suffix','quantity','auto_fill','currency'];

	public function setTagAttribute($value)
    {
        $this->attributes['tag'] = implode(',', $value);
    }

    public function getTagAttribute($value)
	{
		$set_value = [];
		$table_valu = explode(',', $value);

		foreach ($table_valu as $key => $value) {
			$set_value[$value] = $value;
		}

	    return $set_value;
	}

	public function setAutoFillAttribute($value)
    {
    	$return_value = '';
    	
    	if ($value = 'on') {
    		$return_value = 1;
    	}else{
    		$return_value = 0;
    	}

        $this->attributes['auto_fill'] = $return_value;
    }
}
