<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Charge extends Model
{
    protected $table = 'charges';

    protected $fillable = ['store_id','charge_id','name','api_client_id','price','status','return_url','billing_on','test','activated_on','trial_ends_on','cancelled_on','trial_days','decorated_return_url'];
}
