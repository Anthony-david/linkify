<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Store extends Model
{
    protected $table = 'stores';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'shop','shop_timestamp','hmac','token','refreshtoken','shop_id','avatar','install','email','nickname','user'
    ];

    public function setUserAttribute($value)
    {
        $this->attributes['user'] = serialize($value);
    }

    public function getUserAttribute($value)
    {
        return unserialize($value);
    }

    public function getShopifyProduct(){
        return $this->hasMany('App\Models\Product','store_id','id');
    }
}
