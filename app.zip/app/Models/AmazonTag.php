<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AmazonTag extends Model
{
    protected $table = 'amazon_tags';

	protected $fillable = ['id','country_id','affiliate_id','access_key','secret_key'];
}
