@extends('store.layout.layout')
@section('style')
    <?= Html::style('backend/css/dataranger.css',[],IS_SECURE) ?>
@stop
@section('top_fixed_content')
<nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button-->
    <div class="title">
        <h4>Orders</h4>
    </div>
    <div class="pl-10">
        <a href="<?=route('store.draftorder.export')?>" class="btn btn-border btn-sm" title="Export orders">Export Orders</a>
    </div>
    <div class="top_filter"></div>
</nav>
@stop
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card p-0">
            <div class="card-body table-responsive">
                <div class="p-20">
                    <form id="frm_filter" name ="frm_filter">
                        <div class="form-group row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-fw fa-calendar"></i></div>
                                        <input type="text" name="yoy[]" class="form-control pull-right" id="date_range_1">
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="col-md-2">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <?= Form::select('draft_order_id',$draft_order_id, old('draft_order_id'),array('class' => 'form-control draft_order_id','id'=>'draft_order_id_change','placeholder'=>'Draft Order Id')) ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <?= Form::select('dotnet_id',$dotnet_id, old('dotnet_id'),array('class' => 'form-control dotnet_id','id'=>'dotnet_id_change','placeholder'=>'Dotnet Id')) ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <?= Form::select('customer',$customer_name, old('customer'),array('class' => 'form-control customer','id'=>'customer_change','placeholder'=>'Customer')) ?>
                                    </div>
                                </div>
                            </div> -->
                            <div class="col-md-3">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <button type="button" onclick="ChangeUrl()" class="btn btn-primary filter" title="Filter"><i class="fa fa-filter"></i> Filter orders</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body table-responsive">
                <ul class="nav nav-tabs">
                    <li @if(Request::get('order_status') == "completed") class="active" @endif>
                        <a href="<?= URL::route('store.draft-order.index',['order_status'=>'completed']) ?>">Order</a>
                    </li>
                    <li @if(Request::get('order_status') == "open") class="active" @endif>
                        <a href="<?= URL::route('store.draft-order.index',['order_status'=>'open']) ?>">Draft Order</a>
                    </li>
                </ul>
                <div class="p-10">
                    <div class="text-right">
                        <div class="number-delete">
                            <ul>
                                <li>
                                    <p class="mb-0"><span class="num_item"></span>Item Selected.</p>
                                </li>
                                <li class="bulk-dropdown"><a href="javascript:;">Bulk actions<span class="caret"></span></a>
                                    <div class="bulk-box">
                                        <div class="bulk-tooltip"></div>
                                        <ul class="bulk-list">
                                            <li><a href="javascript:void(0);" id="delete" class="delete-btn">Delete selected User</a></li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <table id="draft_order_table" class="table">
                    <thead>
                        <tr>
                            <th class="select-all no-sort">
                                <div class="animated-checkbox">
                                    <label class="m-0">
                                        <input type="checkbox" id="checkAll"/>
                                        <span class="label-text"></span>
                                    </label>
                                </div>
                            </th>
                            <th>Draft Order</th>
                            <th>Customer Name</th>
                            <th>Total Price</th>
                            <th>Order Date</th>
                            <th>Invoice Number</th>
                            @if(Request::get('order_status') == "completed")
                                <th>Order ID</th>
                            @else
                                <th>Action</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
            @include('store.layout.overlay')
        </div>
    </div>
</div>
@stop

@section('script')
<?=Html::script('backend/js/jquery.form.min.js', [], IS_SECURE)?>
<?=Html::script('backend/plugins/datatable/jquery.dataTables.min.js', [], IS_SECURE)?>
<?=Html::script('backend/plugins/datatable/dataTables.bootstrap.min.js', [], IS_SECURE)?>
<?=Html::script('backend/plugins/sweetalert/sweetalert.min.js', [], IS_SECURE)?>
<?= Html::script('backend/js/fnstandrow.js',[],IS_SECURE) ?>
<?=Html::script('backend/js/delete_script.js', [], IS_SECURE)?>
<?= Html::script('backend/js/moment.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/dateranger.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/select2.min.js',[],IS_SECURE) ?>

<script type="text/javascript">
var table = "draft_order_table";
var confirm_order_path = "<?= URL::route('store.draft-order.confirm_order')?>";
var database_url = "<?=URL::route('store.draft-order.index')?>";
var token = "<?=csrf_token()?>";

function confirmOrder(confirm_order_path,draft_order_id,token){
    var url = confirm_order_path;
    var id = draft_order_id;

    var invoice_number = $('.invoice_number'+id).val();

    if(invoice_number == '')
    {
        toastr.error('Please add invoice number');
    }
    else{
        $.post({
            url: url,
            data: { "_token":token, "id": id ,"invoice_number":invoice_number },
            dataType: 'json',
            beforeSubmit : function()
            {
                
            },
            success : function(resp)
            {
                if (resp.success == true) {
                    toastr.success('Order has confirm.')
                }
                var redrawtable = $('#draft_order_table').dataTable();
                redrawtable.fnStandingRedraw();
            }
        })
    }
}


function ChangeUrl(){
    var date_range = $('#frm_filter').serializeArray();
    var redrawtable = $('#draft_order_table').dataTable();
    redrawtable.fnStandingRedraw();
}

$(function(){

    var status = "<?= Request::get('order_status') ?>";

    if(status == 'open'){
        datatable_url = "<?=URL::route('store.draft-order.index',['order_status' => 'status'])?>";
        datatable_url = datatable_url.replace('status',status);
    }
    else if(status == 'completed'){
        datatable_url = "<?=URL::route('store.draft-order.index',['order_status' => 'status'])?>";
        datatable_url = datatable_url.replace('status',status);
    }

    $('#date_range_1').daterangepicker(
    {
        ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
        'This Year': [moment().startOf('year').startOf('days'),moment()],
        'Last Year': [moment().subtract('month',12).startOf('days'), moment().subtract(moment(),12).endOf('days')]
      },
      opens : "right",
      startDate: moment(),
      endDate: moment()
    });

    var redrawtable = $('#draft_order_table').DataTable({
        "bProcessing": false,
        "bServerSide": true,
        "autoWidth": false,
        "sAjaxSource": database_url,
        "fnServerParams": function( aoData ){

            @if(Request::get('order_status') == 'open')
                var order_status = "open";
            @endif

            @if(Request::get('order_status') == 'completed')
                var order_status = "completed";
            @endif

                var form_data = $('#frm_filter').serializeArray();
                $.each(form_data, function(i, val){
                    aoData.push(val);
                });
                aoData.push({ "name": "act", "value": "fetch" });
                server_params = aoData;

            aoData.push({ name:'order_status',value:order_status});
            server_params = aoData;
        },
        "aaSorting": [[ 1,"desc"]],
        "orderSequence": [ "asc" ],
        "aoColumns": [

        {
            mData: "id",
            bSortable:false,
            sWidth:"2%",
            sClass:"text-center",
            mRender: function (v, t, o) {
                return '<div class="animated-checkbox"><label class="m-0"><input class="checkbox" type="checkbox" id="chk_'+v+'" name="special_id['+v+']" value="'+v+'"/><span class="label-text"></span></label></div>';
            },
        },
        {   
            mData:"draft_order_name",bSortable : true,sWidth:"20%",
            mRender : function(v,t,o){

                var edit_path = "<?=URL::route('store.draft-order.show', ['id' => ':id'])?>";

                edit_path = edit_path.replace(':id',o['id']);

                var act_html  = '<a title="Edit '+o['name']+'" href="'+edit_path+'">'+ v +'</a>'
                return act_html;
            }
        },
        { 
            mData:"customer_name",bSortable : true,sWidth:"15%",
            mRender : function(v,t,o){
                var customer_detail = '<span class="pull-left"><b>'+o['customer_name']+"</b><br> "+o['customer_email']+""+"<br> "+o['customer_mobile']+"";
                return customer_detail;
            }
        },
        {   
            mData:"order_total_price",bSortable : true,sWidth:"15%",
        },
        {
            mData:"created_at",
            bSortable : false,
            sWidth:"10%",
            mRender: function (v, t, o) {

                var my_date = dtConvFromJSON(o.created_at);

                return my_date;
            }
        },
        @if(Request::get('order_status') == "open")
        {   
            mData: "invoice_number",
            bSortable: flase,
            sWidth: "10%",
            sClass: "text-center",
            mRender: function(v, t, o) {
                if(v != '' && v != null)
                {
                    var act_html = '<div><input type="text" value='+v+' class="invoice_number'+o['id']+'"></div>';
                }else{
                    var act_html = '<div><input type="text" class="invoice_number'+o['id']+'"></div>';
                }

                return act_html;
            }
        },
        @else
        {
            mData:"invoice_number",bSortable : flase,sWidth:"10%",
        },
        @endif
        {
            mData: null,
            bSortable: false,
            sWidth: "10%",
            sClass: "text-center",
            mRender: function(v, t, o) {
                var id= o['id'];
                if(v['order_status'] == "completed"){
                    var act_html = o['order_id'];
                }else{
                    var act_html = "<div class='btn-group'>"
                        +"<a href='javascript:void(0);' onclick=\"confirmOrder('"+confirm_order_path+"','"+id+"','"+token+"')\" data-toggle='tooltip' title='Confirm Order' data-placement='top' class='btn btn-xs btn-danger p-5' id='temp'>Confirm</a>"
                        +"</div>"
                }
                return act_html;
            }
        }
        ],
        fnPreDrawCallback : function() { $("div.overlay").css('display','flex'); },
        fnDrawCallback : function (oSettings) {
            $("div.overlay").hide();
        }

    });
    $.fn.dataTable.ext.errMode = 'none';
});


$('.draft_order_id').select2({
    placeholder : "Draft Order Id"
});
$('.dotnet_id').select2({
    placeholder : "Dotnet Id"
});
$('.customer').select2({
    placeholder : "Customer"
});
function dtConvFromJSON(data)
{
    var date = new Date(data);
    var month = date.getMonth() + 1;

    return  date.getDate() + "/" + (month.length > 1  ? month : month) + "/" + date.getFullYear();
}
</script>

@stop
