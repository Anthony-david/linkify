<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ButtonRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            "button_text" => "required"    
        ];
    }

    public function messages(){
        return [
            "button_text" => "Please enter button text"    
        ];
    }
}
