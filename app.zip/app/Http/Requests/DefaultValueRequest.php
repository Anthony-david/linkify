<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DefaultValueRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'store' => 'required',
            'product_type' => 'required',
            'vendor' => 'required',
            'tag' => 'required',
            'template_suffix' => 'required',
            'quantity' => 'required | numeric',
        ];
    }

    public function messages()
    {
        return [
            'store.required' => 'Please select store',
            'product_type.required' => 'Please enter product type',
            'vendor.required' => 'Please enter vendor',
            'tag.required' => 'Please enter tag',
            'template_suffix.required' => 'Please template suffix',
            'quantity.required' => 'Please enter quantity',
            'quantity.numeric' => 'Please enter numeric value',
        ];
    }
}
