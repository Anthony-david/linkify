<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AccountRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $data = $this->all();

        return [
            'name' => 'required |regex:/^[\pL\s]+$/u',
            'email' => 'required | email|unique:accounts,email,'.$data['store_id'],
            'website'=>'required',
            'plan' => 'required'
        ];
    }
    public function messages()
    {
        return [
            'name.required' => 'Please enter name',
            'name.regex'=>'Please enter name in valid format',
            'email.required' => 'Please enter email',
            'email.email' => 'Please enter valid email',
            'email.unique' => 'This email already exists',
            'website.required'=>'Please enter website',
            'website.url'=>'Please enter website in valid format',
            'plan.required'=>'Please select plan',
        ];
    }
}
