<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AmazonTagRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'country_id' => 'required',
            'affiliate_id' => 'required',
            'access_key' => 'required',
            'secret_key' => 'required'
        ];
    }

    public function messages()
    {
        return [
            'country_id.required' => 'Please select country',
            'affiliate_id.required' => 'Please enter affiliate id',
            'access_key.required' => 'Please enter access Key',
            'secret_key.required' => 'Please enter secret key'
        ];
    }
}
