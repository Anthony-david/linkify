<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MarkupPricingRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'new_product' => 'required',
            'amazon_multiplier_price' => 'required|numeric',
            'amazon_markup_price' => 'required|numeric',
            'shopify_multiplier_price' => 'required|numeric',
            'shopify_markup_price' => 'required|numeric',
            'cents_price' => 'required|numeric',
            'cents_comp_price' => 'required|numeric',
        ];
    }

    public function messages(){
        return [
            'new_product.required' => 'Select New Product Time',
            'amazon_multiplier_price.required' => 'Please enter amazon multiplier price',
            'amazon_multiplier_price.numeric' => 'Must be decimal value',
            'amazon_markup_price.required' => 'Please enter amazon markup price',
            'amazon_markup_price.numeric' => 'Must be decimal value',
            'shopify_multiplier_price.required' => 'Please enter shopify multiplier price',
            'shopify_multiplier_price.numeric' => 'Must be decimal value',
            'shopify_markup_price.required' => 'Please enter shopify markup price',
            'shopify_markup_price.numeric' => 'Must be decimal value',
            'cents_price.required' => 'Please enter cent price',
            'cents_price.numeric' => 'Must be decimal value',
            'cents_comp_price.required' => 'Please enter cents_comp_price price',
            'cents_comp_price.numeric' => 'Must be decimal value',
        ];   
    }
}
