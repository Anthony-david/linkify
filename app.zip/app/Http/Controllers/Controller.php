<?php
namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Session,Config;
use App\Models\Store;
use App\Models\AmazonTag;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    protected $store_info;
    protected $store_id;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
                
            if ($request->segment(1) != 'admin') {
            	$user = Session::get('user');

               	// $this->store_id = 30;
                // $this->store_info = Store::where('id',22)->first()->toArray();

            	$this->store_id = $user['id'];
            	$this->store_info = $user;
                
                $amazon_tag_details = AmazonTag::where('store_id',$this->store_id)->first();
                
                if ($amazon_tag_details != null  and $amazon_tag_details->count()) {
                    Config::set('amazon-product.associate_tag',$amazon_tag_details->affiliate_id);
                    Config::set('amazon-product.country',$amazon_tag_details->country_id);
                }

            }
            
            return $next($request);
        });
    }
}
