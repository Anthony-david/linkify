<?php

namespace App\Http\Controllers\MainAdmin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MainAdminController extends Controller
{

    public function index(){
    	return view('main-admin.dashboard');
    }
}
