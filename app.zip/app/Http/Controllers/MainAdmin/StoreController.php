<?php

namespace App\Http\Controllers\MainAdmin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Store;
use Log,Shopify;
use App\Jobs\PorductSyncJob;
use GuzzleHttp\Exception\RequestException;

class StoreController extends Controller
{
    public function index(Request $request)
    {
        if($request->ajax()){
            $where_str    = "1 = ?";
            $where_params = array(1); 
            if (!empty($request->input('sSearch')))
            {
                $search     = $request->input('sSearch');
                $where_str .= " and ( email like \"%{$search}%\""
                           ."or shop like \"%{$search}%\""
                           ."or nickname like \"%{$search}%\""
                            . ")";
            }                                            

            $columns = array('id','shop','email','nickname','install');
             
            $store_columns_count = Store::select('id')
                                    ->where('email','!=',null)
                                    ->whereRaw($where_str, $where_params);

            $store_list = Store::select($columns)
                                    ->where('email','!=',null)
                                    ->whereRaw($where_str, $where_params);

            if($request->get('iDisplayStart') != '' && $request->get('iDisplayLength') != '')
            {
                $store_list = $store_list->take($request->input('iDisplayLength'))
                                     ->skip($request->input('iDisplayStart'));
            }    
            
            if($request->get('iSortCol_0') != '')
            {
                $sql_order='';
                for ( $i = 0; $i < $request->input('iSortingCols'); $i++ )
                {
                    $column = $columns[$request->input('iSortCol_' . $i)];
               
                    if(false !== ($index = strpos($column, ' as '))){
                        $column = substr($column, 0, $index);
                    }
                    $store_list = $store_list->orderBy($column,$request->input('sSortDir_'.$i));   
                }
            }

            $store_columns_count = $store_columns_count->count();
            $store_list = $store_list->get();

            $response['iTotalDisplayRecords'] = $store_columns_count;
            $response['iTotalRecords'] = $store_columns_count;
            $response['sEcho'] = intval($request->get('sEcho'));
            $response['aaData'] = $store_list->toArray();
            return $response;
        }
        return view('main-admin.store.index');
    }

    public function show($id){
        $store_data = Store::where('id',$id)->get()->toArray();
        
        return view('main-admin.store.show',compact('store_data'));
    }

    public function destroy(Request $request){
        $store_id = $request->get('id');
            
        if(!is_array($store_id))
        {
            $store_id = array($store_id);
        }

        $store_delete = Store::whereIn('id',$store_id)->delete();

        return response()->json(array('success' => true),200);
    }

    public function syncProduct(Request $request)
    {
        $store_details = Store::with('getShopifyProduct')
                                    // ->where('id',91)
                                    ->where('install',1)
                                    ->get();
        
        if ($store_details != '') {
            $store_details = $store_details->toArray();

            foreach ($store_details as $key => $single_store_detail) {
            
                try {
                    $shop_auth = Shopify::retrieve($single_store_detail['shop'], $single_store_detail['token']);

                    if (isset($single_store_detail['get_shopify_product']) and count($single_store_detail['get_shopify_product'])) {
                        $products = $single_store_detail['get_shopify_product'];
                        Log::info(1);
                        foreach ($products as $key => $single_product) {
                            if(isset($single_product['asin']) and $single_product['asin'] != ''){
                                // $this->dispatch(new PorductSyncJob($single_product['asin'],$single_store_detail['id']))->delay(now()->addSeconds(2));
                                $product_link = $single_product['page_url'];
                                $extension = parse_url($product_link);
                                $product_link = explode('/',$product_link);

                                $extension = $extension['host'];
                                $extension = explode('www.amazon.',$extension);
                                $extension = $extension[1];
                                Log::info($extension);
                                PorductSyncJob::dispatch($single_product['asin'],$single_store_detail['id'],$extension);
                            }
                        }
                    }
                } catch (RequestException $e) {
                    Log::error('sync error');
                    Log::error($e);
                }
            }
        }

        return redirect()->route('main-admin.store.index')->with('message','Product sync successfully')->with('message_type','success');
    }
}