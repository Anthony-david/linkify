<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Helpers\ShopifyClient;
use Illuminate\Http\Request;
use App\Jobs\UploadFileToShopifyJob;
use App\Jobs\EditProductFileShopifyJob;
use App\Models\Store;
use App\Models\Charge;
use Shopify;
use ShopifyBilling;
use Log;

class ShopifyAuthorizeController extends Controller
{

    public function index(Request $request){
        
        $shop_name = $request->get('shop');

        $store_save = Store::firstOrNew(['shop'=>$shop_name]);
        $store_save->save();

        $shopifyClient = new ShopifyClient($shop_name, "", SHOPIFY_API_KEY, SHOPIFY_SECRET);

        header("Location: " . $shopifyClient->getAuthorizeUrl(SHOPIFY_SCOPE,SHOPIFY_REDIRECT));
        exit;
    }

    public function getResponse(Request $request)
    {
        $shop_name = $request->get('shop');
      
        $shopifyClient = new ShopifyClient($shop_name, "", SHOPIFY_API_KEY, SHOPIFY_SECRET);
        $accesstoken = $shopifyClient->getAccessToken($request->get('code'));


        $user_details = Shopify::retrieve($shop_name, $accesstoken);
        $user = $user_details->getUser();
    
        $store_chk = Store::where('shop',$shop_name)->first(); 
        $request->session()->put('user',$store_chk->toArray());

        if ($store_chk->install == 1) {
            return redirect()->to('/dashboard');   
        }


        $store_save = Store::firstOrNew(['shop'=>$shop_name]);
        $store_save->token = $user->token;
        $store_save->refreshtoken = $user->refreshToken;
        $store_save->shop_id = $user->id;
        $store_save->avatar = $user->avatar;
        $store_save->email = $user->email;
        $store_save->nickname = $user->nickname;
        $store_save->user = $user->user;
        $store_save->install = 1;
        $store_save->save();

        $details = [
            'webhook' => [
                'topic' => 'app/uninstalled',
                'address' => URL_PATH.'api/uninstall',
                'format' => 'json'
            ]
        ];

        dispatch(new UploadFileToShopifyJob($shop_name,$accesstoken));
        dispatch(new EditProductFileShopifyJob($shop_name,$accesstoken));

        $webhook_create = Shopify::retrieve($shop_name, $accesstoken)->create('webhooks',$details,[]);

        Log::info('created');
        Log::info($webhook_create);
        Log::info(URL_PATH.'api/uninstall');

        // $url = 'https://'.$shop_name.'/admin/apps/caefc88a75a0d920f9b81d6f32b2b1b6';
        // return redirect()->to($url);
        // 
        $return_url = url('activate');

        $options =  [
                        'name'=>'Linkify', 
                        'price' => 5,
                        'return_url' => $return_url,
                        'trial_days' => 0
                    ];

        $get_charge_details = Charge::where('store_id',$user->id)
                                        ->where('status','accepted')
                                        ->first();
        // $created_at = date('Y-m-d',strtotime($store_save->created_at));
        // $today_date = date('Y-m-d');

        if ($get_charge_details == '') {
            $options['trial_days'] = 3;
        }

        $request->session()->put('flow',1);

        return ShopifyBilling::driver('RecurringBilling')
                                ->create($user, $options)->redirect()->with('user_bill', $user);
    }

    public function billUrl(){

        $store_info = $this->store_info;
        
        $user_details = Shopify::retrieve($store_info['shop'], $store_info['token']);
        $user = $user_details->getUser();

        $return_url = url('activate');

        $options =  [
                        'name'=>'Linkify', 
                        'price' => 5,
                        'return_url' => $return_url,
                        'trial_days' => 0
                    ];

        $get_charge_details = Charge::where('store_id',$store_info['shop_id'])
                                        ->where('status','accepted')
                                        ->first();
        // $created_at = date('Y-m-d',strtotime($store_save->created_at));
        // $today_date = date('Y-m-d');

        if ($get_charge_details == '') {
            $options['trial_days'] = 3;
        }                  

        return ShopifyBilling::driver('RecurringBilling')
                                ->create($user, $options)->redirect()->with('user_bill', $user);   
    }

    public function activate(Request $request){
        $user = $request->session()->get('user_bill');

        $charge_detail = ShopifyBilling::driver('RecurringBilling')
                                    ->getChargeById($user->name, $user->token, $request->get('charge_id'));

        
        if (count($charge_detail) and isset($charge_detail['recurring_application_charge'])) {

            $charge_detail = $charge_detail['recurring_application_charge'];

            $charge_save = new Charge();
            $charge_save->fill($charge_detail);
            $charge_save->store_id = $user->id;
            $charge_save->charge_id = $charge_detail['id'];
            $charge_save->save();

            if ($charge_detail['status'] == 'accepted') {
                $activated = ShopifyBilling::driver('RecurringBilling')
                                ->activate($user->name, $user->token, $request->get('charge_id'));
            }

            
            $url = 'https://'.$user->name.'/admin/apps/caefc88a75a0d920f9b81d6f32b2b1b6';

            return redirect()->to($url);
        }

    }
}
