<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\AmazonTagRequest;
use App\Events\AmazonTagEvent;
use App\Models\Store;
use App\Models\AmazonTag;
use Event;

class AmazonTagController extends Controller
{
    public function index(){
        $amazon_tag = AmazonTag::where('store_id',$this->store_id)->orderBy('updated_at','desc')->first();
     
    	return view('admin.amazon-tag.index',compact('amazon_tag'));
    }

    public function store(Request $request){
        
    	$store_id = $this->store_id;

    	$amazontag_details = $request->all();
    	$request_amazontag_details = [
    		'store_id' => $store_id,
    		'amazontag_details' => $amazontag_details
    	];
       
    	Event::fire(new AmazonTagEvent($request_amazontag_details));
    	
    	return redirect()->back()->with('message', 'Amazon Tag Added');
    } 

    public function getValue(Request $request){
    
        $store_id    = $this->store_id;

        $country_id  = $request->country_id;

        $get_value =  AmazonTag::where('country_id',$country_id)->where('store_id',$store_id)->first();
           
        return response()->json(['success'=>true,'value'=>$get_value],200);
    } 
}
