<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Events\AutoSyncEvent;
use App\Models\Store;
use App\Models\AutoSync;
use Validator;
use Event;

class AutoSyncController extends Controller
{
    public function index(){

        $auto_sync = AutoSync::where('store_id',$this->store_id)->first();

    	return view('admin.auto-sync.index',compact('auto_sync'));
    }
    
    public function storeAutoSyncAction(Request $request){

    	$request->validate([
		    'auto_sync_action' => 'required'
		]);

    	$store_id = $this->store_id;
        
		$auto_sync_action_details = $request->all();

    	$request_auto_sync_action_details = [
    		'store_id' => $store_id,
    		'action_credentials_details' => $auto_sync_action_details
    	];

    	Event::fire(new AutoSyncEvent($request_auto_sync_action_details));
    	
    	return redirect()->back()->with('message', 'Auto Sync Action Added');
    }

    public function storeAutoSyncCredentials(Request $request){
    	$request->validate([
		    'product_price' => 'required',
		    'product_stock' => 'required',
		    'discontinue_product' => 'required'
		]);

    	$store_id = $this->store_id;
		$auto_sync_credentials_details = $request->all();
    	$request_auto_sync_credentials_details = [
    		'store_id' => $store_id,
    		'action_credentials_details' => $auto_sync_credentials_details
    	];
    	Event::fire(new AutoSyncEvent($request_auto_sync_credentials_details));
    	
    	return redirect()->back()->with('message', 'Auto Sync Action Added');
    }
}
