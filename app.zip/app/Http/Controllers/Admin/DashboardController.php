<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests\AddProductRequest;
use App\Http\Controllers\Controller;
use App\Jobs\FeatchProductAmazon;
use App\Models\Product;
use App\Models\Charge;
use Session,Config;
use App\Models\DefaultValue;

class DashboardController extends Controller
{
    public function index(Request $request){

        $store_info = $this->store_info;

        $store_main_id = $store_info['shop_id'];

        $charge_details = Charge::where('store_id',$store_main_id)
                                    ->orderBy('id','desc')
                                    ->first();

        if ($charge_details != '' and $charge_details->status == 'accepted') {
            
            $product_list = Product::orderBy('created_at','desc')
                                        ->where('store_id',$this->store_id)
                                        ->get();

            $flow = 0;

            if ($request->session()->has('flow')) {
                $flow = $request->session()->get('flow');
                $request->session()->forget('flow');
            }
                                              	
        	if (count($product_list)) {
    			$product_list = $product_list->toArray();
    		}

        	return view('admin.dashboard',compact('product_list','store_info','flow'));
        }

        return view('admin.charge');
    }

    public function getProduct(AddProductRequest $request){
    	$product_link_main = $request->get('product_link');
    	$product_link = parse_url($product_link_main, PHP_URL_PATH);
    	$product_link = explode('/',$product_link);
        $store_id = $this->store_id;

        $extension = parse_url($product_link_main);
        $extension = $extension['host'];
        $extension = explode('www.amazon.',$extension);
        $extension = $extension[1];

    	$check_product = array_where($product_link, function ($value, $key) {
		    if ($value == 'dp' or $value == 'gp') {
		    	return $key;
		    }
		});
       
        $check_product_key = head(array_keys($check_product));
        $check_product = head($check_product);
        
        if ($check_product == 'dp' and isset($product_link[$check_product_key + 1])) {
            $asin = $product_link[$check_product_key + 1];
        }elseif($check_product == 'gp' and isset($product_link[$check_product_key + 2])){
            $asin = $product_link[$check_product_key + 2];
        }else{
            $asin = '';
        }

		if ($asin != '') {
			$product_link = $asin;
	
			dispatch(new FeatchProductAmazon($product_link,$store_id,$extension));

			$product_list = Product::orderBy('created_at','desc')
                                        ->where('store_id',$this->store_id)
                                        ->get();

            $check_product = Product::where('asin',$asin)
                                        ->where('store_id',$this->store_id)
                                        ->first();

            $check_zero_price = false;                                        
            
            if ($check_product != '') {
                if ($check_product->price == 0 or $check_product->price) {
                    $check_zero_price = true;
                }
            }

			if (count($product_list)) {
				$product_list = $product_list->toArray();
			}

			return response()->json(['success'=>true,'message'=>'Product added successfully','product_list'=>$product_list,'check_zero_price'=>$check_zero_price],200);
    	}

    	return response()->json(['success'=>true,'message'=>'Something went wrong, Please try after sometime'],422);
    }

    public function deleteProduct(Request $request){

       $id = $request->get('id');
      
       $delete_product = Product::where('id',$id)->delete();

       return response()->json(['success'=>true,'message'=>'Amazon Product Deleted'],200);
    }

    public function shopifyProduct($id)
    {
        $product_data = Product::where('id',$id)->first()->toArray();

        $default_value = DefaultValue::where('store_id',$product_data['store_id'])->first();
       
        $midium_images = [];

        if(array_key_exists('other_details', $product_data))
        {   
            if(array_key_exists('Items', $product_data['other_details']))
            {
                if(array_key_exists('Item', $product_data['other_details']['Items']))
                {
                    if(array_key_exists('ItemAttributes', $product_data['other_details']['Items']['Item']))
                    {

                       if(array_key_exists('ItemAttributes', $product_data['other_details']['Items']['Item']))
                       {
                            $product_attribute = $product_data['other_details']['Items']['Item']['ItemAttributes'];

                            if(array_key_exists('ProductTypeName', $product_attribute))
                            {
                                $product_data['product_type'] = $product_attribute['ProductTypeName'];
                            }
                            else
                            {
                                if($default_value != null)
                                {
                                    $product_data['product_type'] = $default_value['product_type'];      
                                }
                            }
                            if($default_value['auto_fill'] == 1)
                            {
                                if(array_key_exists('Publisher', $product_attribute))
                                {
                                    $product_data['vendor'] = $product_attribute['Publisher']; 
                                }
                            }
                            else
                            {
                                $product_data['vendor'] = $default_value['vendor']; 
                            }
                       }
                    }
                    if(array_key_exists('ImageSets',$product_data['other_details']['Items']['Item']))
                    {
                        if(array_key_exists('ImageSet',$product_data['other_details']['Items']['Item']['ImageSets']))
                        {
                            if(array_key_exists('ImageSet', $product_data['other_details']['Items']['Item']['ImageSets']))
                            {
                                 $array_val = $product_data['other_details']['Items']['Item']['ImageSets']['ImageSet'];

                                    foreach ($array_val as $key => $single_value) {

                                        if(array_key_exists('MediumImage', $single_value))
                                        {
                                           $midium_images[$key]['image'] = $single_value['MediumImage']['URL'];

                                        }
                                    }
                            }    
                        }
                    }
                }
            }
        }
        $feature_view = view('admin.product.feature_list',compact('product_attribute'))->render();

        $product_data['body_html'] = $feature_view;

        $product_data['multi_images'] = $midium_images;

        if($default_value != null)
        {      
            $product_data['tags'] = explode(',', $default_value['tag']);
        }

        $product_variants_modified = null;

        $product_data = Product::ProductDataModifyShopify($product_data,$product_variants_modified);
       
        return $product_data;

    }
}
