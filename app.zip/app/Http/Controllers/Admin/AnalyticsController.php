<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\AnalyticsRequest;
use App\Events\AnalyticsEvent;
use App\Models\Store;
use Event;

class AnalyticsController extends Controller
{
    public function index(){
    	return view('admin.analytics.index');
    }
    public function store(Request $request){
        
    	$store_id = $this->store_id;
    	$analytics_details = $request->all();
        
        $request_analytics_details = [
            'store_id' => $store_id,
            'analytics_details' => $analytics_details
        ];
    	Event::fire(new AnalyticsEvent($request_analytics_details));
    	
    	return redirect()->back()->with('message', 'Track Added');
    }
}
