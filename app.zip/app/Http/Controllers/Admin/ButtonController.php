<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ButtonRequest;
use App\Events\ButtonEvent;
use App\Models\Store;
use App\Models\Button;
use Event;

class ButtonController extends Controller
{
    public function index(){
        
        $buttons_details = Button::where('store_id',$this->store_id)->first();

    	return view('admin.button.index',compact('buttons_details'));
    }

    public function store(Request $request){
    	$store_id = $this->store_id;
    	$buttons_details = $request->all();
    	
    	$request_buttons_details = [
    		'store_id' => $store_id,
    		'buttons_details' => $buttons_details
    	];
        
    	Event::fire(new ButtonEvent($request_buttons_details));
    	
    	return redirect()->back()->with('message', 'Button Text Added');
    }
}
