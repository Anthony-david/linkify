<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\DefaultValueRequest;
use App\Events\DefaultValueEvent;
use App\Models\Store;
use App\Models\DefaultValue;
use Event;

class DefaultValueController extends Controller
{
    public function index(){

        $default_value = DefaultValue::firstOrNew(['store_id'=>$this->store_id]);
        
    	return view('admin.default_value.index',compact('default_value'));
    }

    public function store(Request $request){
       
        $this->validate($request, [
            'currency' => 'required',
        ], [
            'currency.required' => 'Please select country.',
        ]);
    	$store_id = $this->store_id;

    	$default_values_details = $request->all();
    
    	$request_default_values_details = [
    		'default_values_details' => $default_values_details,
    		'store_id' => $store_id  
    	];
    	Event::fire(new DefaultValueEvent($request_default_values_details));
    	
    	return redirect()->back()->with('message', 'Default Value Added');
    } 
}