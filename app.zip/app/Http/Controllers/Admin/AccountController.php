<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\AccountRequest;
use App\Events\AccountEvent;
use App\Models\Account;
use App\Models\Store;
use Event;
class AccountController extends Controller
{
    public function index(){

        $account_details = Account::where('store_id',$this->store_id)->first();
        $store_info = $this->store_info;
        
        if ($account_details == '') {
            $account_details = new Account();
            $account_details->store_id = $store_info['id'];
            $account_details->name = $store_info['nickname'];
            $account_details->email = $store_info['email'];
            $account_details->website = $store_info['shop'];
        }
        
    	return view('admin.account.index',compact('account_details'));
    }
    public function store(Request $request)
    {
    	$store_id = $this->store_id;
    	$account_details = $request->all();

    	$request_account_details = [
    		'store_id' => $store_id,
    		'account_details' => $account_details
    	];

    	Event::fire(new AccountEvent($request_account_details));
    	
    	return redirect()->back()->with('message', 'Amazon Account Added');
    }
}
