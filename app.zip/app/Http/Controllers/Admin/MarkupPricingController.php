<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\MarkupPricingRequest;
use App\Events\MarkupPricingEvent;
use App\Models\Store;
use App\Models\MarkupPricing;
use Event;

class MarkupPricingController extends Controller
{
    public function index(){

        $markup_price = MarkupPricing::where('store_id',$this->store_id)->first();

    	return view('admin.markup-price.index',compact('markup_price'));
    }

    public function store(Request $request){
    	$store_id = $this->store_id;

    	$markup_pricing_details = $request->all();
    	$request_markup_pricing_details = [
    		'store_id' => $store_id,
    		'markup_pricing_details' => $markup_pricing_details
    	];
        
    	Event::fire(new MarkupPricingEvent($request_markup_pricing_details));
    	
    	return redirect()->back()->with('message', 'Markup Pricing Added');
    }
}
