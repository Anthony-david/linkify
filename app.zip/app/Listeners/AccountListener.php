<?php

namespace App\Listeners;

use App\Events\AccountEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\Jobs\SaveAccountJob;

class AccountListener
{
    use DispatchesJobs;

    public $request_account_details;

    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle($event)
    {
        $request_account_details = $event->request_account_details;
        
        $request_account_details = $this->dispatch(new SaveAccountJob($request_account_details));
    }
}
