<?php

namespace App\Listeners;

use App\Events\AnalyticsEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\Jobs\SaveAnalyticsJob;

class AnalyticsListener
{
    use DispatchesJobs;
    
    public $request_analytics_details;

    public function __construct()
    {
        //
    }

    
    public function handle(AnalyticsEvent $event)
    {
        $request_analytics_details = $event->request_analytics_details;
        
        $request_analytics_details = $this->dispatch(new SaveAnalyticsJob($request_analytics_details));
    }
}
