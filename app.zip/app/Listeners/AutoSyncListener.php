<?php

namespace App\Listeners;

use App\Events\AutoSyncEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\Jobs\SaveAutoSyncJob;

class AutoSyncListener
{
    use DispatchesJobs;

    public $request_auto_sync_action_details;

    public function __construct()
    {
        //
    }

    
    public function handle(AutoSyncEvent $event)
    {
        $request_auto_sync_action_details = $event->request_auto_sync_action_details;
        
        $request_auto_sync_action_details = $this->dispatch(new SaveAutoSyncJob($request_auto_sync_action_details));
    }
}
