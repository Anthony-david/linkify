<?php

namespace App\Listeners;

use App\Events\MarkupPricingEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\Jobs\SaveMarkupPricingJob;

class MarkupPricingListener
{
    use DispatchesJobs;

    public $request_markup_pricing_details;

    public function __construct()
    {
        //
    }

    
    public function handle(MarkupPricingEvent $event)
    {
        $request_markup_pricing_details = $event->request_markup_pricing_details;
        
        $request_markup_pricing_details = $this->dispatch(new SaveMarkupPricingJob($request_markup_pricing_details));
    }
}
