<?php

namespace App\Listeners;

use App\Events\AmazonTagEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\Jobs\SaveAmazonTagJob;

class AmazonTagListener
{   
    use DispatchesJobs;

    public $request_amazontag_details;

    public function __construct()
    {
        //
    }

    
    public function handle(AmazonTagEvent $event)
    {
        $request_amazontag_details = $event->request_amazontag_details;
        
        $request_amazontag_details = $this->dispatch(new SaveAmazonTagJob($request_amazontag_details));
    }
}
