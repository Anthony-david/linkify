<?php

namespace App\Listeners;

use App\Events\ButtonEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\Jobs\SaveButtonJob;

class ButtonListener
{
    use DispatchesJobs;

    public $request_buttons_details;

    public function __construct()
    {
        //
    }
    
    public function handle(ButtonEvent $event)
    {
        $request_buttons_details = $event->request_buttons_details;
        
        $request_buttons_details = $this->dispatch(new SaveButtonJob($request_buttons_details));
    }
}
