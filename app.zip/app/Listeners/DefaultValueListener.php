<?php

namespace App\Listeners;

use App\Events\DefaultValueEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\DispatchesJobs;
use App\Jobs\SaveDefaultValueJob;

class DefaultValueListener
{
    
    use DispatchesJobs;
    
    public $request_default_values_details;

    public function __construct()
    {
        //
    }

    
    public function handle(DefaultValueEvent $event)
    {
        $request_default_values_details = $event->request_default_values_details;
        
        $request_default_values_details = $this->dispatch(new SaveDefaultValueJob($request_default_values_details));
    }
}
