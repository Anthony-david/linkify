<?php

Route::group(['namespace'=>'Admin'],function(){
	Route::get('/dashboard','DashboardController@index')->name('admin.dashboard.index');
	Route::post('product-delete','DashboardController@deleteProduct')->name('admin.product.delete');
	Route::get('add-shopify-product/{id}','DashboardController@shopifyProduct')->name('admin.add.shopify');

	Route::get('/account','AccountController@index')->name('admin.account.index');
	Route::post('/account','AccountController@store')->name('admin.account.store');
	/* routes for amazon-tag */
	Route::get('/amazon-tag','AmazonTagController@index')->name('admin.amazon-tag.index');
	Route::post('/amazon-tag','AmazonTagController@store')->name('admin.amazon-tag.store');
	Route::post('/getValue','AmazonTagController@getValue')->name('amazon-tag.get.value');

	/* routes for default-values */
	Route::get('/default-values','DefaultValueController@index')->name('admin.default-values.index');
	Route::post('/default-values','DefaultValueController@store')->name('admin.default-values.store');
	
	/* routes for button */
	Route::get('/button','ButtonController@index')->name('admin.button.index');
	Route::post('/button','ButtonController@store')->name('admin.button.store');
	
	/* routes for markup-pricing */
	Route::get('/markup-pricing','MarkupPricingController@index')->name('admin.markup-pricing.index');
	Route::post('/markup-pricing','MarkupPricingController@store')->name('admin.markup-pricing.store');
	
	/* routes for auto-sync */
	Route::get('/auto-sync','AutoSyncController@index')->name('admin.auto-sync.index');
	Route::post('/auto-sync/action','AutoSyncController@storeAutoSyncAction')->name('admin.auto-sync.action');
	Route::post('/auto-sync/credentials','AutoSyncController@storeAutoSyncCredentials')->name('admin.auto-sync.credentials');
	
	/* routes for analytics */
	Route::get('/analytics','AnalyticsController@index')->name('admin.analytics.index');
	Route::post('/analytics','AnalyticsController@store')->name('admin.analytics.store');
	
	Route::post('/get-product','DashboardController@getProduct')->name('admin.dashboard.get_product');
});