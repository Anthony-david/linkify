<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('uninstall',function(Request $request){
	$shop_id = $request->get('domain');
	Log::info($shop_id);
	$chage_status = App\Models\Store::where('shop',$shop_id)
										->update(['install'=>0]);

	return response()->json(200);
});
