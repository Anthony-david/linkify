<?php



Route::group(['namespace'=>'MainAdmin', 'prefix' => 'admin'],function(){
	Route::get('/login', [
	    'as'=>'login.get',
	    'uses'=>'Auth\LoginController@showLoginForm'
	]);

	Route::post('/login',[
		'as' => 'admin.login.post',
		'uses' => 'Auth\LoginController@login'
	]);
	
	Route::group(['middleware'=>'admin'],function(){
		Route::get('logout', 'Auth\LoginController@logout')->name('main-admin.logout');
		Route::get('/dashboard','MainAdminController@index')->name('main-admin.dashboard.index');
		Route::get('/store','StoreController@index')->name('main-admin.store.index');
		Route::get('/store/show/{id}','StoreController@show')->name('main-admin.store.show');
		Route::post('store/delete',[
	        'as' => 'main-admin.store.delete',
	        'uses' => 'StoreController@destroy'
	    ]);

	    Route::get('/getproduct','StoreController@syncProduct')->name('main-admin.product.get');
	});

});