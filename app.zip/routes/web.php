<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     $response = AmazonProduct::item('B01NCN4ICO');

//     echo"<pre>";
//     print_r($response);
//     exit;
// });
// 
// 
Route::get('/',function(){
	return view('frontend.homepage');
});

Route::get('/terms',function(){
	return view('frontend.terms');
});

Route::get('/guide',function(){
	return view('guide');
});

Route::get('/faq',function(){
	return view('frontend.faq');
});

Route::get('/privacy',function(){
	return view('frontend.privacy');
});

Route::get('/check-install',['as'=>'shopify.index','uses'=>'ShopifyAuthorizeController@index']);
Route::get('/oauth/authorize', 'ShopifyAuthorizeController@getResponse');
Auth::routes();

//shopify active url
Route::get('activate', 'ShopifyAuthorizeController@activate');

Route::get('/home', 'HomeController@index')->name('home');

Route::get('testbill',function(){
	$shop_name = 'nirajtestapp.myshopify.com';
	$accesstoken = '33473d99b7c2633d97f6794bffd14160';

	$user_auth = Shopify::retrieve($shop_name, $accesstoken);

	$user = $user_auth->getUser();
	
	$return_url = url('activate');

	$options =  [
					'name'=>'Linkify', 
					'price' => '1',
                	'return_url' => $return_url,
                	'test' => true
                ];

    return ShopifyBilling::driver('RecurringBilling')
                            ->create($user, $options)->redirect()->with('user_bill', $user);
});

Route::get('app-bill-url',['as'=>'app-bill-url','uses'=>'ShopifyAuthorizeController@billUrl']);

Route::get('product',function(){
	// $product_link = 'https://www.amazon.es/dp/B00NLL1EYG/';
	// $product_link = 'https://www.amazon.co.jp/dp/B00NLL1EYG/';
	// $product_link = 'https://www.amazon.in/dp/B00NLL1EYG/';
	// $product_link = 'https://www.amazon.com.br/dp/B00NLL1EYG/';
	// $product_link = 'https://www.amazon.cn/dp/B00NLL1EYG/';
	// $product_link = 'https://www.amazon.com.au/dp/B00NLL1EYG/';
	$product_link = 'https://www.amazon.com/dp/B075JDLM3B/';
	// $product_link = 'https://www.amazon.fr/Philips-Pack-ampoules-connect%C3%A9es-White/dp/B0748MY3S8';

	$extension = parse_url($product_link);
	$product_link = explode('/',$product_link);

	$extension = $extension['host'];
	$extension = explode('www.amazon.',$extension);
	$extension = $extension[1];
	$check_product = array_where($product_link, function ($value, $key) {
		if ($value == 'dp' or $value == 'gp') {
			return $key;
		}
	});

	$check_product_key = head(array_keys($check_product));
	$check_product = head($check_product);

	if ($check_product == 'dp' and isset($product_link[$check_product_key + 1])) {
		$asin = $product_link[$check_product_key + 1];
	}elseif($check_product == 'gp' and isset($product_link[$check_product_key + 2])){
		$asin = $product_link[$check_product_key + 2];
	}else{
		$asin = '';
	}

	if ($asin != '') {
		$product_link = $asin;
		dispatch(new App\Jobs\FeatchProductAmazon($product_link,19,$extension));
	}
	// $product = dispatch(new App\Jobs\ShopifyProductFormatJob(18));

	// $product = dispatch(new App\Jobs\UploadFileToShopifyJob('linkifytesting.myshopify.com','e16ca2c6e5d7c69174880c7f2804e430'));	
	// 
	// $product = dispatch(new App\Jobs\PorductSyncJob());
	// $shop_auth = Shopify::retrieve('linkifytesting.myshopify.com','d02efd742bd0c40f67ff0d01e552d5dc');
	// $themes = $shop_auth->get('products');

	echo"<pre>";
	// print(arg)t_r($themes);
	exit;
	// $themes = $shop_auth->get('themes');
	
	// foreach ($themes['themes'] as $key => $single_theme) {
	// 	$asset = $shop_auth->get('themes/'.$single_theme['id'].'/assets');

	// 	$liquid = $shop_auth->get('themes/'.$single_theme['id'].'/assets?asset[key]=sections/product-template.liquid&theme_id='.$single_theme['id']);

	// 	if (isset($liquid['asset']) and count($liquid['asset'])) {
	// 		$content = $liquid['asset']['value'];

	// 		$liquid_array = explode(PHP_EOL, $content);
			
	// 		foreach ($liquid_array as $single_key => $single_line) {
	// 			if (trim($single_line) == "{% form 'product', product, class:form_classes %}") {
	// 				$single_line = $single_line.'{% include "linkify"%}';
	// 				$liquid_array[$single_key] = $single_line;
	// 			}
	// 		}

	// 		$liquid_array = implode("\n", $liquid_array);

	// 		$modify_data = [
	// 			'key' => 'sections/product-template.liquid',
	// 			'value' => $liquid_array
	// 		];

	// 		$asset_details['asset'] = $modify_data;
			
	// 		$modifiy_templete = $shop_auth->modify('themes/'.$single_theme['id'].'/assets',$asset_details);

	// 		echo"<pre>";
	// 		print_r($modifiy_templete);
	// 		exit;
	// 	}

	// }
});
