@extends('main-admin.layout.layout')
@section('style')
    <?= Html::style('backend/plugins/sweetalert/sweetalert.min.css',[],IS_SECURE) ?>
@stop
@section('top_fixed_content')
<nav class="navbar navbar-static-top">
<div class="title">
    <h4><i class="fa fa-shopping-cart" aria-hidden="true"></i>Store</h4>
</div>
<div class="col-md-7 text-right">
    <a href="{{ route('main-admin.product.get') }}" class="btn btn-primary btn-sm"> <i class="fa fa-refresh" aria-hidden="true"></i> Sync</a>
</div>
</nav>
@stop
@section('content')
<div class="row">
<div class="col-md-12">
    <div class="card">
        <div class="card-body table-responsive">
            <div class="text-right">
                <div class="number-delete">
                    <ul>
                        <li>
                            <p class="mb-0"><span class="num_item"></span>Item Selected.</p>
                        </li>
                        <li class="bulk-dropdown"><a href="javascript:;">Bulk actions<span class="caret"></span></a>
                            <div class="bulk-box">
                                <div class="bulk-tooltip"></div>
                                <ul class="bulk-list">
                                    <li><a href="javascript:void(0);" id="delete" class="delete-btn">Delete selected Zone</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="clearfix"></div>
            </div>
            <table id="store_table" class="table">
                <thead>
                    <tr>
                        <th class="select-all no-sort">
                            <div class="animated-checkbox">
                                <label class="m-0">
                                    <input type="checkbox" id="checkAll"/>
                                    <span class="label-text"></span>
                                </label>
                            </div>
                        </th>
                        <th>Shop</th>
                        <th>Email</th>
                        <th>Nickname</th>
                        <th>Install</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
        @include('main-admin.layout.overlay')
    </div>
</div>
</div>
@stop
@section('script')
<?= Html::script('backend/js/jquery.form.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/plugins/jquery.dataTables.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/plugins/dataTables.bootstrap.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/plugins/sweetalert/sweetalert.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/fnstandrow.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/delete_script.js',[],IS_SECURE) ?>
<?= Html::script('backend/plugins/select2/js/select2.full.min.js',[],IS_SECURE) ?>

<script type="text/javascript">
var table = "store_table";
var title = "Are you sure to delete this Store?";
var text = "You will not be able to recover this record";
var type = "warning";
var delete_path = "<?= URL::route('main-admin.store.delete') ?>";
var token = "<?= csrf_token() ?>";
function closeModel()
{
    $("[id$='_error']").empty();
    $('#status_form_data')[0].reset();
}


$(function(){
    $('#delete').click(function(){
        var delete_id = $('#'+table+' tbody .checkbox:checked');
        checkLength(delete_id);
        
    });

     $('#store_table').DataTable({
        "bProcessing": false,
        "bServerSide": true,                              
        "autoWidth": false,
        "sAjaxSource": "<?= URL::route('main-admin.store.index') ?>",
        "aaSorting": [[ 0,"desc"]],
        "orderSequence" : ["desc"],
        "aoColumns": [

        {
            mData: "id",
            bVisible:false,
            sWidth:"5%",
            sClass:"text-center",
            mRender: function (v, t, o) {
                return '<div class="animated-checkbox"><label class="m-0"><input class="checkbox" type="checkbox" id="chk_'+v+'" name="special_id['+v+']" value="'+v+'"/><span class="label-text"></span></label></div>';
            },
        },
        
        {   mData:"shop",sWidth:"20%",bSortable : true,
            mRender : function(v,t,o){

                var edit_path = "<?= URL::route('main-admin.store.show',['id'=>':id']) ?>";
                edit_path = edit_path.replace(':id',o['id']);
            
                var act_html  = '<a title="Show '+o['shop']+'" href="'+edit_path+'">'+ v +'</a>'
                
                return act_html;
            }
        },
        {   mData:"email",bSortable : false,sWidth:"30%" },
        {   mData:"nickname",bSortable : false,sWidth:"25%" },
        {   mData:"install",
            bSortable : false,
            sClass : 'text-center',
            sWidth:"20%",
            mRender: function (v, t, o) {
                var active_string;
                
                if (v == '1') {
                    active_string = "<span class='badge bg-info'>Yes</span>";
                }else{
                    active_string = "<span class='badge bg-default'>No</span>";
                }
                return active_string;
            },
        },
        ],
        fnPreDrawCallback : function() { $("div.overlay").css('display','flex'); },
        fnDrawCallback : function (oSettings) {
            $("div.overlay").hide();
        }

    });      
});
</script>
@include('main-admin.layout.alert')
@stop