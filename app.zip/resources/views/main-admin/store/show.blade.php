@extends('main-admin.layout.layout')
@section('style')
    <?= Html::style('backend/plugins/sweetalert/sweetalert.min.css',[],IS_SECURE) ?>
@stop
@section('top_fixed_content')
<nav class="navbar navbar-static-top">
<div class="title">
    <h4><i class="fa fa-shopping-cart" aria-hidden="true"></i>Store Detail / <a href="<?=route('main-admin.store.index')?>">Store</a></h4>
</div>
<div class="top_filter"></div>
</nav>
@stop
@section('content')
<div class="row">
    <div class="col-md-12">
        <section class="panel panel-info">
            <header class="panel-heading">
                Store Details
            </header>
            <div class="panel-body">
                @foreach($store_data as $store_data_value)
                    @foreach($store_data_value as $single_store_data_key => $single_store_data_value)
                    @if($single_store_data_key != 'themes')
                        <div class="col-md-2">
                            <h5>{{$single_store_data_key}}</h5>
                        </div>
                        <div class="col-md-1">
                            <h5>:</h5>
                        </div>
                        <div class="col-md-8">
                            @if(!empty($single_store_data_value))
                                @if(is_array($single_store_data_value))
                                    <h5>
                                        <b>Name</b>  : {{ $single_store_data_value['name'] }}<br>
                                        <b>Email</b> : {{ $single_store_data_value['email'] }}<br>
                                        <b>Domain</b>: {{ $single_store_data_value['domain'] }}<br>
                                        <b>Address</b>: {{$single_store_data_value['address1']}}
                                    </h5>
                                @else
                                <h5>{{$single_store_data_value}}</h5>
                                @endif
                            @else
                                <h5>N/A</h5>
                            @endif
                        </div>
                    @endif
                    @endforeach
                @endforeach
            </div>
        </section>
    </div>
</div>
@stop
@section('script')
    <script type="text/javascript">
    </script>
@include('main-admin.layout.alert')
@stop