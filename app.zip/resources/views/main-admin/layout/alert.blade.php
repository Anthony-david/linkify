@section('style_toastr')
	<?= Html::style('backend/plugins/toastr-master/toastr.min.css',[],IS_SECURE) ?>
@stop
@section('script_toastr')
	<?= Html::script('backend/plugins/toastr-master/toastr.min.js',[],IS_SECURE) ?>
@stop
@if(Session::has('message'))
	@if(Session::get('message_type'))
		<script>
	        $(document).ready(function(){
		        toastr.{{ Session::get('message_type') }}
		        ('{{ Session::get('message') }}');
	        });
	    </script>
    @endif
@endif