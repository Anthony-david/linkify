<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#ffffff">
        <link rel="shortcut icon" href="#">
        <title>Main Admin Amazon Shopify</title>
        <!-- File to add css files to page -->
        @include('main-admin.layout.web_header')
        @yield('style')
    </head>
    <body id="body-collapse"  class="sidebar-mini fixed">
        <div class="wrapper">
            @yield('start_form')
            <!-- Header file -->
            @include('main-admin.layout.header')
            <!-- Side-Bar-->
            @include('main-admin.layout.sidebar')
            <!-- Contant Start here -->
            <div class="content-wrapper">
                @yield('content')
            </div>
            <!-- footer contant -->
            @yield('end_form')
        </div>
        <!-- Js file -->
        @yield('modal')
        @include('main-admin.layout.footer')
        <script type="text/javascript">
        </script>
    </body>
</html>