<aside class="main-sidebar hidden-print">
    <section class="sidebar">
        <a href="#" class="logo"></a>
        <div class="search-panel">
            <div class="p-10">
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-menu">
                <li class="@if(Request::segment(2) == 'dashboard') active @endif">
                    <a href="<?= URL::route('main-admin.dashboard.index')?>">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                    </a>
                </li>
                <li class="@if(Request::segment(2) == 'store') active @endif">
                    <a href="<?= URL::route('main-admin.store.index')?>">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    <span>Store</span>
                    </a>
                </li>
                <li class="@if(Request::segment(2) == 'log') active @endif">
                    <a href="<?= url('admin/log') ?>" target="_blank">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    <span>System Log</span>
                    </a>
                </li>
                <li class="@if(Request::segment(2) == 'horizon') active @endif">
                    <a href="<?= url('horizon') ?>" target="_blank">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    <span>Sync Status</span>
                    </a>
                </li>
                <li class="spacer"></li>
                <li class="logout"><a href="javascript:;"><i class="fa fa-user"></i>
                <span></span>
                <i class="fa fa-angle-right"></i></a>
                    <ul class="logout-modal">
                        <li><a href="#"> Change Password</a></li>
                        <li><a href="<?= URL::route('main-admin.logout')?>"> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </section>   
</aside>
