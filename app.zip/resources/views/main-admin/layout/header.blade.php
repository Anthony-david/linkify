<header class="main-header hidden-print"> 
    <a href="" class="logo">
        	
    <p class="small">Main Admin</p>
	<div data-toggle="offcanvas" class="sidebar-toggle"></div>
    </a>
	@yield('top_fixed_content')
</header>