@extends('main-admin.layout.layout')
@section('style')
	<?= Html::style('backend/css/bootstrap-reset.css',[],IS_SECURE) ?>
@stop
@section('top_fixed_content')
    <nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button-->
        <div class="title">
            <h4><i class="fa fa-dashboard"></i> Dashboard</h4>
        </div>
    </nav>
@stop