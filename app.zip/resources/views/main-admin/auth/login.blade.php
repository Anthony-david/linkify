<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="#">
        <title>Amazon Shopify</title>
        <?= Html::style('backend/plugins/toastr-master/toastr.min.css',[],IS_SECURE) ?>
        <?= Html::style('backend/css/main.css',[],IS_SECURE) ?>
    </head>
    <body>
        <section class="material-half-bg">
        </section>
        <section class="login-content">
            <div class="login-box">
                <div class="login_logo">
                    <p class="m-0">LINKIFY</p>
                </div>
                <?= Form::open(['route'=>'admin.login.post','id'=>'login_form','class'=>'form-signin ps-relative']) ?>
                    {{ csrf_field() }}
                    <div class="login-head">
                        <h3 class="m-0 text-center">Log in to Your Account</h3>
                    </div>
                    <div class="form-group @if($errors->first('email')) has-error @endif">
                        <label class="control-label">USERNAME</label>
                        <?= Form::email('email',null,['class'=>'form-control mb-0','autofocus','placeholder'=>'Enter your email']) ?>
                        <span class="color-w"><?= $errors->first('email') ?></span>
                    </div>
                    <div class="form-group @if($errors->first('password')) has-error @endif">
                        <label class="control-label">PASSWORD</label>
                        <?= Form::password('password',['class'=>'form-control mb-0','placeholder'=>'Enter your password']) ?>
                        <span class="color-w"><?= $errors->first('password') ?></span>
                    </div>
                    <div class="form-group">
                        <div class="utility">
                        </div>
                    </div>
                    <div class="form-group btn-container">
                      <button class="btn btn-primary btn-block form-control">SIGN IN <i class="fa fa-sign-in fa-lg"></i></button>
                    </div>
                <?= Form::close() ?>
                @include('admin.layout.overlay')
            </div>
        </section>
    </body>
        <!-- js placed at the end of the document so the pages load faster -->
        <?= Html::script('backend/js/jquery-2.1.4.min.js',[],IS_SECURE) ?>
        <?= Html::script('backend/js/essential-plugins.js',[],IS_SECURE) ?>
        <?= Html::script('backend/js/bootstrap.min.js',[],IS_SECURE) ?>
        <?= Html::script('backend/plugins/toastr-master/toastr.min.js',[],IS_SECURE)  ?>
        <?= Html::script('backend/js/main.js',[],IS_SECURE) ?> 

        <script type="text/javascript"> 
        </script>
</html>