@extends('frontend.layout.layout')
@section('css')
<?= Html::style('frontend/css/reset.css',[],IS_SECURE) ?>
<?= Html::style('frontend/css/style.css',[],IS_SECURE) ?>
<?= Html::script('frontend/js/modernizr.js',[],IS_SECURE) ?>
@stop
@section('content')



        <h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-2" style="padding:10% 0% 0% 0%;">
            Getting Started (Guide)</h2>
            
<section style="padding:2% 5%;">
<p class="b"><span style="font-weight: 600; font-size:20px; color:#1e0233;"><span class="b" style="color:#906;">Step 1. Copy Amazon Product Link </span></p></span> <br>
<p><span style="font-weight: 400; font-size:16px;">Copy the Amazon link on the product page	 </span></p> <br><br>
<img src="frontend/assets/images/Screenshot 1.png" width="100%"  alt="Screenshot1">
<br><br>
</section>


<section style="padding:2% 5%;">
<p><span style="font-weight: 600; font-size:20px;"><span class="b" style="color:#906;">Step 2. Paste Amazon Product Link Click on Search </span></p></span> <br>
<p><span style="font-weight: 400; font-size:16px;">Paste the link on the Dashboard of the Linkify App	 </span></p> <br><br>
<img src="frontend/assets/images/Screenshot 2.png" width="100%" alt="Screenshot2">
<br><br>
</section>

<section style="padding:2% 5%;">
<p><span style="font-weight: 600; font-size:20px;"><span class="b" style="color:#906;">Step 3. Thats It! Product has been added to your Shopify Account </span></p></span> <br>
<p><span style="font-weight: 400; font-size:16px;">You can View, edit and delete the product on the option on Linkify Dashboard	 </span></p> <br><br>
<p><span style="font-weight: 600; font-size:20px;"><span class="b" style="color:#906;">Step 4. Button Automatically changes to "View on Amazon" But yo can also have "Add to cart" Button. (Setting for "Add to cart" button in step 6) </span></p></span> <br>
<p><span style="font-weight: 400; font-size:16px;">You can View, edit and delete the product on the option on Linkify Dashboard	 </span></p> <br><br>
<img src="frontend/assets/images/Screenshot 3.png" width="100%" alt="Screenshot3">
<br><br>
</section>

<section style="padding:2% 5%;">
<a id="btnaddtocart"></a><p><span style="font-weight: 600; font-size:20px;"><span class="b" style="color:#906;">Step 5. For Amazon Affiliate Add you Affiliate ID (Shown in the inage below) </span></p></span> <br>
<p><span style="font-weight: 400; font-size:16px;">Add your Amazon Affiliate to get commission for sale through your website </span></p> <br><br>
<p><span style="font-weight: 600; font-size:20px;     line-height: 30px;"><span class="b" style="color:#906;">Step 6. [ "Add to Cart Button" ] For Dropshipping from Amazon --> Click on Top Right Corner Menu on LINKIFY APP --> Click Default Values Tab --> Add the Tag "linkify-hidden" (As shown in below Image)--> Save.</span></p></span> <br>
<p><span style="font-weight: 400; font-size:16px;">	Dropshipping products has to shipped by the Website holder and also manage return.Customer support for the products </span></p> <br><br>
<img src="frontend/assets/images/Screenshot 4.jpg" width="100%" alt="Screenshot4">
<br><br>
</section>



@stop
@section('js')
<?= Html::script('frontend/js/jquery-2.1.1.js',[],IS_SECURE) ?>
<?= Html::script('frontend/js/jquery.mobile.custom.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/js/main.js',[],IS_SECURE) ?>
@stop