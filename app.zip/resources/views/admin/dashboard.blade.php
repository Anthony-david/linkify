@extends('admin.layout.layout')
@section('style')
<style>
    [ng\:cloak], [ng-cloak], [data-ng-cloak], [x-ng-cloak], .ng-cloak, .x-    ng-cloak {
    display: none !important;
    }
</style>
<link href="https://fonts.googleapis.com/css?family=Nosifer" rel="stylesheet">
@stop
@section('content')
<!-- <div id="myModal" class="modal fade" role="dialog" Style:"display:none;">
    <div class="modal-dialog">
      <!-- Modal content-->
<!--    <div class="modal-content">
    <div class="modal-header" style="display:none">
      <button type="button" class="close" data-dismiss="modal">&times;</button>
      <h4 class="modal-title">Happy Halloween</h4>
    </div>
    <div class="modal-body" style="padding: 0px;">
    
      <img src="https://admin.abc.sm/img/gallery/upload/422/img_lastminute_282293.png" alt="Happy Halloween Wishes" class="imagepromo"><span id="demo" style=" position: absolute;bottom: 123px;left: 25px;font-size: 35px;font-weight: 600;color: #fcb205;font-family:Nosifer;" class="timer"></span>
    </div>
    <div class="modal-footer" style="border-top: 0px solid #934609;background-color: #934609;">
      <button type="button" class="btn btn-info btnn" data-dismiss="modal">Thank You (Close)</button>
    </div>
    </div>
    
    </div>
    </div> -->
<!-- <div id="myModalproduct" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <h3>There are some error to fetch product
                <br>
                    It's fetched with zero price
                <br>
                Please try again</h3>
            </div>
        </div>
    </div>
</div>   -->

<div class="loader-section">
    <div class="loader"></div>
    <span>Featching products from Amazon to your store</span>
</div>
<div ng-app="AddProduct" ng-controller="AddProductController" ng-cloak>
    <section class="panel panel-info">
        <header class="panel-heading">
            <p> Add Product<button type="button" class="btn btn-info" style="padding:5px 5px; font-size: 12px; float:right;"><a href="https://mylinkify.com/guide" target="_blank">Guide to Import Product</a></button>
            </p>
        </header>
        <div class="row" style="height:95px;">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="input-group m-bot15 searchbox">
                    <input type="text" class="form-control" ng-model="product_link" placeholder="Copy Amazon product link here">
                    <span class="input-group-btn">
                    <button type="button" class="btn btn-info" ng-click="addProduct(product_link)">Search</button>
                    </span>
                </div>
                <div class="addSpace" style="padding-top: 6px">
                    <p style="padding-top: 5px;"><span style="color: #f44336;"> Amazon.com & Amazon.in Products can be Imported </p>
                    <!--    <p style="padding-top: 5px;"><span style="color: #f44336;">Sorry for inconvenience!!!
                        Since Amazon server are down today and Product Import is unavailable today.</span><br>
                                        <b> As a token of sorry we are giving out free Developer Support for you Shopify Store.</b>
                          <br><span style="font-size: 13px;">To avail the <span style="color: #f44336;">Giveaway </span> email your Store URL on <a href="https://mail.google.com/mail/?view=cm&amp;fs=1&amp;to=support@mylinkify.com&amp;su=&amp;body=&amp;bcc=" target="_blank" class="waves-effect waves-light">support@mylinkify.com</a> with Subject "Server Issue"</span>
                        
                          </p> -->
                    <span class="text-danger"><% error_message %></span>
                    <span class="text-success"><% success_message %></span>
                </div>
            </div>
            <div class="col-md-2"></div>
        </div>
    </section>
    <div class="row">
        <!--     <div class="col-md-1"></div> -->
        @if(count($product_list))
        <div class="col-md-9">
            <section class="panel panel-info">
                <header class="panel-heading1">
                    <div class="additioninfo1">
                        <a href="https://mylinkify.com/guide#btnaddtocart" target="_blank" class="waves-effect waves-light"> To set</a>
                        <button type="button" class="btn btn-info waves-effect waves-dark" style="padding:5px 5px; font-size: 12px;">Add to Cart</button>
                        <a href="https://mylinkify.com/guide#btnaddtocart" target="_blank" class="waves-effect waves-light">button on product page Click here  </a>
                    </div>
                </header>
                <header class="panel-heading">
                    <div class="products_top_heading">
                        Product List 
                    </div>
                    <div class="additioinformationdesktop" ">
                        <a href="https://mylinkify.com/guide#btnaddtocart" target="_blank"> To set</a>
                        <button type="button" class="btn btn-info waves-effect waves-dark" style="padding:5px 5px; font-size: 12px;">Add to Cart</button>
                        <a href="https://mylinkify.com/guide#btnaddtocart" target="_blank">button on product page Click here  </a>
                    </div>
                </header>
                <table class="table table-striped table-advance table-hover">
                    <thead>
                        <!-- <tr>
                            <th width="90%">Company</th>
                            <th width="10%" style="text-align:center">Action</th>
                            </tr> -->
                    </thead>
                    <tbody>
                        <tr ng-repeat="single_product_list in product_list" ng-if="product_list.length != 0">
                            <td width="85%">
                                <div class="row">
                                    <div class="col-md-1">
                                        <img class="alignLeft" ng-src="<% single_product_list.medium_image %>">
                                    </div>
                                    <div class="col-md-11">
                                        <p><% single_product_list.title %></p>
                                        <p>Brand : <% single_product_list.brand %></p>
                                        <p>Price : <% single_product_list.price %></p>
                                    </div>
                                </div>
                            </td>
                            <td width="15%" align="center">
                                <a class="btn btn-primary btn-xs" target="_blank" href="https://<?= $store_info['shop'] ?>/products/<% single_product_list.handle %>"><i class="fa fa-eye"></i></a>
                                <a class="btn btn-primary btn-xs" target="_blank" href="https://<?= $store_info['shop'] ?>/admin/products/<% single_product_list.shopify_product_id %>"><i class="fa fa-pencil"></i></a>
                                <a class="btn btn-primary btn-xs" href="javascript:void(0)" ng-click="refreshProduct(single_product_list)"><i class="fa fa-refresh"></i></a>
                                <button class="btn btn-danger btn-xs" ng-click="delProduct(single_product_list.id)"><i class="fa fa-trash-o "></i></button>
                            </td>
                        </tr>
                        <tr ng-if="product_list.length == 0">
                            <td align="center" colspan="2">
                                <h4>No product avalible</h4>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </section>
        </div>
        @else
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
                <li data-target="#myCarousel" data-slide-to="3"></li>
            </ol>
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item active">
                    <div class="col-md-12">
                        <section class="panel panel-info">
                            <header class="panel-heading">
                                Getting Started
                            </header>
                            &nbsp;&nbsp;&nbsp; 
                            <p style="padding:0% 15% 0% 10%"><b >1) Select Your Country</b><br><br>&nbsp;&nbsp;&nbsp;Add your Native country that you are Targeting<br></p>
                            <img src="<?=asset('frontend/flow/5.png')?>" style="width:80%; padding:0% 10% 0% 10%;" alt="Los Angeles">
                        </section>
                    </div>
                </div>
                <div class="item">
                    <div class="col-md-12">
                        <section class="panel panel-info">
                            <header class="panel-heading">
                                Getting Started
                            </header>
                            &nbsp;&nbsp;&nbsp; 
                            <p style="padding:0% 15% 0% 10%"><b >2) Copy Amazon Product Link</b><br><br>&nbsp;&nbsp;&nbsp;Copy the amazon link on the product page<br></p>
                            <img src="<?=asset('frontend/flow/1.png')?>" style="width:80%; padding:0% 10% 0% 10%;" alt="Los Angeles">
                        </section>
                    </div>
                </div>
                <div class="item">
                    <div class="col-md-12">
                        <section class="panel panel-info">
                            <header class="panel-heading">
                                Getting Started
                            </header>
                            &nbsp;&nbsp;&nbsp; 
                            <p style="padding:0% 15% 0% 10%"><b>3) Past the amazon product link and Click on Search</b><br><br>&nbsp;&nbsp;&nbsp;Paste the Link on the Dashboard of Linkify App<br></p>
                            <img src="<?=asset('frontend/flow/2.png')?>" style="width:80%; padding:0% 10% 0% 10%; alt="Los Angeles">
                        </section>
                    </div>
                </div>
                <div class="item">
                    <div class="col-md-12">
                        <section class="panel panel-info">
                            <header class="panel-heading">
                                Getting Started
                            </header>
                            &nbsp;&nbsp;&nbsp; 
                            <p style="padding:0% 15% 0% 10%"><b>4) Product has beed added to your Shopify Account</b><br><br>&nbsp;&nbsp;&nbsp;You can view, edit and delete the product on the Linkify Dashboard<br></p>
                            &nbsp;&nbsp;&nbsp;
                            <p style="padding:0% 15% 0% 10%"> <b>5) Button Automatically changes to "View on Amazon" but you can have "Add to Cart" buttin.(View Step 5 for "Add to cart" Button)</b><br><br>&nbsp;&nbsp;&nbsp;You can change to "Add to Cart" Button by simple step<br></p>
                            <img src="<?=asset('frontend/flow/3.png')?>" style="width:80%; padding:0% 10% 0% 10%; alt="Los Angeles">
                        </section>
                    </div>
                </div>
                <div class="item">
                    <div class="col-md-12">
                        <section class="panel panel-info">
                            <header class="panel-heading">
                                Getting Started
                            </header>
                            &nbsp;&nbsp;&nbsp;
                            <p style="padding:0% 15% 0% 10%"> <b>6) For Amazon Affiliate Add your Affiliate ID on the Amazon Tag Menu</b><br><br>&nbsp;&nbsp;&nbsp;Add your Amazon Affiliate to get commission for the sale throught  your website<br></p>
                            &nbsp;&nbsp;&nbsp;
                            <p style="padding:0% 15% 0% 10%"> <b>7) For Dropshipping product from Amazon Add the tag "linkify-hidden" on the Default Tag Menu</b><br><br>&nbsp;&nbsp;&nbsp;Dropshipping product has to be delivery by the website holder and also to manage return product.<br></p>
                            <img src="<?=asset('frontend/flow/4.jpg')?>" style="width:80%; padding:0% 10% 0% 10%; alt="Los Angeles">
                        </section>
                    </div>
                </div>
                <!-- Left and right controls -->
                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <span class="fa fa-chevron-left" style="font-size:36px"></span>
                </a>
                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                <span class="fa fa-chevron-right" style="font-size:36px"></span>
                </a> 
            </div>
        </div>
        @endif
        <div class="col-md-3">
            <section class="panel panel-info">
                <header class="panel-heading">
                    <p> Add-ons</p>
                </header>
                @if(count($product_list))
                <tbody>
			
					<tr>
                        <td>
								<div class="row" style="background-color: #f5f6f7; margin-left: 0px;margin-right: 0px;">
									<div class="col-md-12" style="padding-left: 22px;">
								<h4 style="color: #f44336;border-color: #bce8f1; font-size:35px; " class="shake">Add Snow Effect on your Website (FREE)</h4>
								<p >Setup snow Effect on your Website <b>for free</b> celebrate this christmas with a BANG<br><br>
								<span style="font-size: 13px;">To avail the <span style="color: #f44336;">Giveaway </span> email your Store URL on <a href="https://mail.google.com/mail/?view=cm&amp;fs=1&amp;to=support@mylinkify.com&amp;su=&amp;body=&amp;bcc=" target="_blank" class="waves-effect waves-light">support@mylinkify.com</a></span>
								<br>
								<!--<span style="font-size: 10px;padding-left: 235px;">T&C APPLY. </span> -->
								</p>
									</div>
								</div>
							 </td>
                    </tr>
                    <tr>
                        <td>
								<div class="row">
									<div class="col-md-12" style="padding-left: 22px;">
								<h4 style="color: #f44336;border-color: #bce8f1;">Christmas MEGA Giveaway</h4>
								<p>Get Free personal Developer to <b>Setup/ Develop and Design</b> your Shopify Store for this christmas Season.<br><br>
								<span style="font-size: 13px;">To avail the <span style="color: #f44336;">Giveaway </span> email your Store URL on <a href="https://mail.google.com/mail/?view=cm&amp;fs=1&amp;to=support@mylinkify.com&amp;su=&amp;body=&amp;bcc=" target="_blank" class="waves-effect waves-light">support@mylinkify.com</a></span>
								<br>
								<span style="font-size: 10px;padding-left: 235px;">T&C APPLY. </span>
								</p>
									</div>
								</div>
							 </td>
                    </tr>
                    <tr>
                        <td>
								<div class="row" style="background-color: #f5f6f7; margin-left: 0px;margin-right: 0px;">
									<div class="col-md-12" style="padding-left: 22px;">
								<h4 style="color: #f44336;border-color: #bce8f1;">Pre New-Year Giveaway</h4>
								<p>Start this <b>New Year with New Website Design </b> for your shopify Store.<br><br>
								<span style="font-size: 13px;">To avail the <span style="color: #f44336;">Giveaway </span> email your Store URL on <a href="https://mail.google.com/mail/?view=cm&amp;fs=1&amp;to=support@mylinkify.com&amp;su=&amp;body=&amp;bcc=" target="_blank" class="waves-effect waves-light">support@mylinkify.com</a></span>
								<br>
								<span style="font-size: 10px;padding-left: 225px;">T&C APPLY. </span></p>
									</div>
								</div>
							 </td>
                    </tr>
                </tbody>
                @else
                <!--  <tbody>
                    <tr >
                    <td align="center" colspan="2">
                    <h4>No products</h4>
                    </td>
                    </tr>
                    </tbody> -->
                @endif
            </section>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>
@stop
@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.0/angular.min.js"></script>
<script type="text/javascript">
    var delete_product = '<?= route('admin.product.delete') ?>';
    var get_product = '<?= route('admin.dashboard.get_product') ?>';
    var product_list = <?= json_encode($product_list) ?>;
</script>
<?= Html::script('backend/js/addproduct.js',[],IS_SECURE) ?>
<?=Html::script('backend/js/sweetalert.min.js', [], IS_SECURE)?>
<script type="text/javascript">
    $(window).load(function(){        
      $('#myModal').modal('show');
       }); 
</script>
<script type="text/javascript">
    @if($flow == 1)
     $('#myModal').modal('show');
    @endif
</script>
<script type="text/javascript">
    // Set the date we're counting down to
    var countDownDate = new Date("Oct 31, 2018 23:59:59").getTime();
    
    // Update the count down every 1 second
    var x = setInterval(function() {
    
        // Get todays date and time
        var now = new Date().getTime();
        
        // Find the distance between now and the count down date
        var distance = countDownDate - now;
        
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        // Output the result in an element with id="demo"
        document.getElementById("demo").innerHTML = days + "d " + hours + "h "
        + minutes + "m " + seconds + "s ";
        
        // If the count down is over, write some text 
        if (distance < 0) {
            clearInterval(x);
            document.getElementById("demo").innerHTML = "EXPIRED";
        }
    }, 1000);
</script>
@stop