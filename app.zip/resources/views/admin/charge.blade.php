<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#ffffff">
        <meta name="csrf-token" content="{{ csrf_token() }}" />
        <link rel="shortcut icon" href="">
        <title>Amazon Shopify</title>
        <!-- File to add css files to page -->
        @include('admin.layout.web_header')
    </head>
    <body class="full-width">
        <section id="container" class="">
            <section id="main-content">
                <div class="wrapper wrapper_body">
                    <section class="panel panel-info">
                        <header class="panel-heading">
                            Charge Approval
                        </header>
                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-8">
                                <h3>Kindly approve the payment to access application by clicking below link</h3><br>
                                <a href="<?= route('app-bill-url') ?>" target="_blank">Approve here</a>
                            </div>
                            <div class="col-md-2"></div>
                        </div>
                    </section>
                </div>
            </section>
        </section>
        @include('admin.layout.footer')
        <script type="text/javascript">
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>
    </body>
</html>