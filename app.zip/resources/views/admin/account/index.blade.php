@extends('admin.layout.layout')
	@section('style')
	@stop
@section('content')
	@if(session()->has('message'))
	<div class="row">
		<div class="col-md-1"></div>
	    <div class="col-md-10 alert alert-success">
	        {{ session()->get('message') }}
	    </div>
	    <div class="col-md-1"></div>
	</div>
	@endif
	<div class="row">
		<div class="col-md-1"></div>
		<div class="col-md-12">
			<!-- <div class="col-md-offset-10">
				<button type="button" class="btn btn-default pull-right">Boost SEO</button>
				<br>
		    </div> -->
		    <br>
			<section class="panel panel-info">
				<header class="panel-heading">
					Account Details
				</header>
				<div class="panel-body">
		            <!-- <form class="form-horizontal" role="form"> -->
		              <?=Form::model($account_details,['route' => 'admin.account.store', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal m-0'])?>

		                <div class="form-group">
		                  	<label for="name" class="col-md-2 control-label">Name</label>
		                  	<div class="col-md-8">
		                      	<?=Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Name']);?>
		                        <span id="name_error" class="help-inline text-danger"><?=$errors->first('name')?></span>
		                  	</div>
		              	</div>
		              	<?=Form::hidden('store_id', null, []);?>
		              	<div class="form-group">
		                  	<label for="email" class="col-md-2 control-label">Email</label>
		                  	<div class="col-md-8">
		                      	<?=Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Email']);?>
		                        <span id="email_error" class="help-inline text-danger"><?=$errors->first('email')?></span>
		                  	</div>
		              	</div>

		              	<div class="form-group">
		                  	<label for="website" class="col-md-2 control-label">Website</label>
		                  	<div class="col-md-8">
		                      	<?=Form::text('website', null, ['class' => 'form-control', 'placeholder' => 'fashionic.com']);?>
		                        <span id="website_error" class="help-inline text-danger"><?=$errors->first('website')?></span>
		                  	</div>
		              	</div>

		              	<!-- <div class="form-group">
		                  	<label for="plan" class="col-md-2 control-label">Plan</label>
		                  	<div class="col-md-8">
		                        <div class="input-group m-bot15">
		                        	<?=Form::text('plan', null, ['class' => 'form-control', 'placeholder' => 'Basic - $5 per month','id'=>'account_plan']);?>
                                  <input type="text" class="form-control" placeholder="Basic - $5 per month" id="account_plan" name="plan">
                                  <div class="input-group-btn">
                                      <button type="button" class="btn btn-success aaaa dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Change Plan <span class="caret"></span></button>
                                      <ul class="dropdown-menu pull-right change_plan">
                                          <li><a href="#">Plan 1</a></li>
                                          <li><a href="#">Plan 2</a></li>
                                      </ul>
                                  </div>
                              	</div>
                              	<span id="plan_error" class="help-inline text-danger"><?=$errors->first('plan')?></span>
		                  	</div>
		                </div> -->
		                <div class="form-group">
		                    <div class="col-lg-offset-6">
		                        <button type="submit" value="save" class="btn btn-info" style="background-color:#41cac0"><b>Save</b></button>
		                    </div>
		                </div>
		            <?=Form::close();?>
		      </div>
			</section>
		</div>
		<div class="col-md-1"></div>
	</div>
@stop
@section('script')
<script type="text/javascript">
	
	@if(old('plan'))
		var old_plan = {!! json_encode(old('plan')) !!};
		$('#account_plan').val(old_plan);
	@endif

	$('ul.change_plan li').click(function(){
		$('#account_plan').val($(this).find('a').text());
	});
</script>
@stop


