@extends('admin.layout.layout')
@section('style')
@stop
@section('content')
<div class="row">
<div class="col-md-12">
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
  	<section class="panel panel-info">
      	<header class="panel-heading">
          	Enter the text to be displayed on the Amazon link button
      	</header>
      <div class="panel-body">
          	<!-- <form class="form-horizontal" role="form"> -->
              <?=Form::model($buttons_details,['route' => 'admin.button.store', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal m-0'])?>
              	<div class="form-group">
                  	<label for="button_text" class="col-md-4 control-label">Button Text</label>
                  	<div class="col-md-4">
                      	<?=Form::text('button_text',$buttons_details != '' ? null : 'View on Amazon' , ['class' => 'form-control', 'placeholder' => 'View on Amazon']);?>
                        <span id="button_text_error" class="help-inline text-danger"><?=$errors->first('button_text')?></span>
                  	</div>
              	</div>

              	<div class="form-group">
                  	<div class="col-lg-offset-6">
                      	<button type="submit" class="btn btn-primary"><b>Save</b></button>
                  	</div>
              	</div>
          	<!-- </form> -->
            <?=Form::close()?>
      	</div>
  	</section>
</div>
</div>
<!-- <div class="row">
    <div class="col-md-12">
        <section class="panel panel-info detail_box">
            <header class="panel-heading">
                 Amazon Button Text
            </header>
            <div class="panel-body">
                <p><b>Amazon Button Text</b></p>
                <p>Add a clear call-to-action to show link to Amazon. Do not use 'Buy on Amazon' since it violates Amazon's trademark.</p>  
            </div>
        </section>
    </div>
</div> -->
@stop
@section('script')
  <script type="text/javascript">
  </script>    
@stop

