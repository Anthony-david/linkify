<div class="col-md-2">
    <section class="panel">
      <div class="list-group">
          <a class="list-group-item @if(Request::segment(1) == 'amazon-tag') active @endif" href="<?= URL::route('admin.amazon-tag.index')?>">Amazon Tag</a>
          <a class="list-group-item @if(Request::segment(1) == 'default-values') active @endif" href="<?= URL::route('admin.default-values.index')?>">Default Values</a>
          <a class="list-group-item @if(Request::segment(1) == 'button') active @endif" href="<?= URL::route('admin.button.index')?>">Button</a>
          <a class="list-group-item @if(Request::segment(1) == 'markup-pricing') active @endif" href="<?= URL::route('admin.markup-pricing.index')?>">Markup Pricing</a>
      </div>
    </section>
</div>