<!-- CSS-->
<?= Html::style('backend/font-awesome/css/font-awesome.min.css',[],IS_SECURE) ?>

<?= Html::style('backend/css/style_hori.css',[],IS_SECURE) ?>
<?= Html::style('backend/css/main.css',[],IS_SECURE) ?>
<?= Html::style('backend/css/binary.css',[],IS_SECURE) ?>
<?= Html::style('backend/css/custom.css',[],IS_SECURE) ?>
<?= Html::style('backend/css/bootstrap-reset.css',[],IS_SECURE) ?>
<?= Html::style('backend/css/linkify.css',[],IS_SECURE) ?>
@yield('style_toastr')