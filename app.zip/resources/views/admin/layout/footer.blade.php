<!-- javascript -->
<?= Html::script('backend/js/jquery-2.1.4.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/essential-plugins.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/bootstrap.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/plugins/pace.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/plugins/jquery.slimscroll.min.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/plugins/waves.js',[],IS_SECURE) ?>
<?= Html::script('backend/js/timeout.js',[],IS_SECURE) ?>
@yield('script_toastr')
@yield('script')
<script type="text/javascript">
	@if(count($errors))
		toastr.error('Something went wrong please check');
	@endif
    $(document).ready(function(){

        $('#success').delay(3000).fadeOut('slow');
        $('#danger').delay(3000).fadeOut('slow');
        $('#warning').delay(3000).fadeOut('slow');
    });
    $.ajaxSetup({
        statusCode: {
            401: function() {
                swal({
                   title: "Session Timeout",
                   type:"error",
                   timer: 2000,
                   showConfirmButton: false 
                });
                location.reload();
            }
        }
    });
</script>
<script type="text/javascript">
  function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
<?= Html::script('backend/js/main.js',[],IS_SECURE) ?>