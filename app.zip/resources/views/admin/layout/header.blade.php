<header class="header">

    <div class="navbar-header">

        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">

        <span class="fa fa-bars"></span>

        </button>

        <!--logo start-->

        <a href="<?= route('admin.dashboard.index') ?>" class="logo" ><img src="<?=asset('backend/images/logo.png')?>" height="48px" width="50px" style="margin-bottom:1px"></a>

        <!--logo end-->

   

        <button type="button" class="btn btn-info none">For Email Support: <a href="https://mail.google.com/mail/?view=cm&fs=1&to=support@mylinkify.com&su=&body=&bcc=" target="_blank">support@mylinkify.com</a>

        </button> 

              

        <div id="mySidenav" class="sidenav">

            <span href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="cursor:pointer;">×</span>

            <a href="<?= route('admin.dashboard.index') ?>">Home</a>

            <a href="<?= URL::route('admin.amazon-tag.index')?>">Amazon Tag</a>

            <a href="<?= URL::route('admin.default-values.index')?>">Default Values</a>

            <a href="<?= URL::route('admin.button.index')?>">Button</a>

            <a href="<?= URL::route('admin.markup-pricing.index')?>">Markup Pricing</a>

            <!-- <a href="<?= URL::route('admin.auto-sync.index')?>">Auto-Sync <i class="fa"></i></a> -->

            <a href="<?= route('admin.account.index') ?>">Account</a>

        </div>

        <span class="pull-right" style="font-size:25px;cursor:pointer;margin-top: 20px;" onclick="openNav()"><i class="fa fa-align-right"></i></span>

      

    </div>

</header>