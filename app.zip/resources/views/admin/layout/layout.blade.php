<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#ffffff">
        <meta name="csrf-token" content="{{ csrf_token() }}" />
        <link rel="shortcut icon" href="">
        <title>Amazon Shopify</title>
        <!-- File to add css files to page -->
        <style type="text/css">
            #container{
                position: relative;
            }
            #container .full-width #main-content{
                position: relative;
                height: 100%;

            }
            .loader-section {
                height: 100%;
                position: absolute;
                left: 0;
                background-color: #33333345;
                z-index: 3;
                right: 0;
                display: none;
                align-items: center;
                text-align: center;
                justify-content: center;
            }
            .loader-section span{
                position: absolute;
                top: 27%;
                color: #ffffff;
                font-size: 24px;
            }
            .loader {
                border: 16px solid #f3f3f3; /* Light grey */
                border-top: 16px solid #3498db; /* Blue */
                border-radius: 50%;
                width: 120px;
                height: 120px;
                animation: spin 0.9s linear infinite;
                position: absolute;
                top: 100px
            }

            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
        @include('admin.layout.web_header')
        @yield('style')
    </head>
    <body class="full-width">
        @include('admin.layout.header')
        <section id="container" class="">
            <section id="main-content">
                <div class="wrapper wrapper_body">
                    @if((Request::segment(1) != "dashboard") and (Request::segment(1) != "account"))
                    @endif
                    @yield('content')
                </div>
            </section>
        </section>
        @include('admin.layout.footer')
        <script type="text/javascript">
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>
    </body>
</html>