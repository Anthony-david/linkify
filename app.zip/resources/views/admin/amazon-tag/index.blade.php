@extends('admin.layout.layout')
@section('style')
@stop
@section('content')
<div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-12">
    @if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
    @endif
    <section class="panel panel-info">
        <header class="panel-heading">
            Enter your Amazon Affiliate ID
        </header>
        <div class="panel-body">
            <!-- <form class="form-horizontal" role="form"> -->
            <?=Form::model($amazon_tag,['route' => 'admin.amazon-tag.store', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal m-0','id'=>'amazon_form'])?>
            <div class="form-group @if($errors->has('country_id')) {{ 'has-error' }} @endif">
                <label class="col-md-4 control-label">Select Country</label>
                <div class="col-md-4">
                    {!! Form::select('country_id',Config::get('CountryCode'), 1, ['class' => 'form-control full has-error','id' => 'country_id' ]) !!}
                    <span id="country_id_error" class="help-inline text-danger"><?=$errors->first('country_id')?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputAffiliateID" class="col-md-4 control-label">Affiliate / Associate ID</label>
                <div class="col-md-4">
                    <?=Form::text('affiliate_id', null, ['class' => 'form-control', 'placeholder' => 'amztag-20','id'=>'affiliate_id']);?>
                    <span id="affiliate_id_error" class="help-inline text-danger"><?=$errors->first('affiliate_id')?></span>
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-offset-4">
                    <a href="https://affiliate-program.amazon.com/" target="_blank">Amazon Affiliate US</a>
                </div>
            </div>
            <div class="form-group">
                <label for="inputAffiliateID" class="col-md-4 control-label">AWS Access key</label>
                <div class="col-md-4">
                    <?=Form::text('access_key', null, ['class' => 'form-control', 'placeholder' => 'access_key','id'=>'access_key']);?>
                    <span id="access_key_error" class="help-inline text-danger"><?=$errors->first('access_key')?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputAffiliateID" class="col-md-4 control-label">AWS Secret key</label>
                <div class="col-md-4">
                    <?=Form::text('secret_key', null, ['class' => 'form-control', 'placeholder' => 'secret_key','id'=>'secret_key']);?>
                    <span id="secret_key_error" class="help-inline text-danger"><?=$errors->first('secret_key')?></span>
                </div>
            </div>
            <div class="form-group">
                <div class="col-lg-offset-6">
                    <button type="submit" class="btn btn-primary"><b>Save</b></button>
                </div>
            </div>
            <!-- </form> -->
            <?=Form::close()?>
        </div>
    </section>
</div>
</div>
<!-- <div class="row">
    <div class="col-md-6">
        <section class="panel panel-info detail_box">
            <header class="panel-heading">
                Amazon Disclouser Policy
            </header>
            <div class="panel-body">
                <p>You must put the affiliate disclose statement on your site.</p>
                <a href="#">Know more...</a><br><br>
                <a href="#">Amazon Affiliate FAQs</a>
            </div>
        </section>
    </div>
    <div class="col-md-6">
        <section class="panel panel-info detail_box">
            <header class="panel-heading" style="height:43px;">
            </header>
            <div class="panel-body">
               <p>Add Amazon Affiliate ID for only the Amazon country / region from where you want to import products.</p>
            </div>
        </section>
    </div>
</div> -->
@stop
@section('script')
<?=Html::script('backend/js/select2.min.js', [], IS_SECURE)?>
<script type="text/javascript">
    function setValue(country,type = 0){
        var token  = "<?=csrf_token()?>";
        $.ajax({
            type: "post",
            url: "<?=route('amazon-tag.get.value')?>",
            data: {'country_id':country,'token':token},
            success: function (data) {
                
                if(data.value != null)
                {
                    $.each(data.value,function(k,v){
                        $('#'+k).val(v);
                    });
                }else
                {
                    $('#affiliate_id').val('');
                    $('#access_key').val('');
                    $('#secret_key').val('');
                }

                if (type == 1) {
                    $('#affiliate_id').val('');
                    $('#access_key').val('');
                    $('#secret_key').val('');
                }
            }
        });

        return false;
    }

    $(document).ready(function(){

        $('#country_id').select2({
            'placeholder':"Select Country"
        });
        var country = $('#country_id').val();

        setValue(country,1);
    });
</script>    
<script type="text/javascript">

    $('#country_id').on('change',function(){
        var country = $(this).val();

        setValue(country);
    });
</script>
@if(Session::has('message'))
<script type="text/javascript">
    var get_msg = '{{ Session::get("check_wallet_blnc") }}';
    $('#affiliate_id').val('');
    $('#access_key').val('');
    $('#secret_key').val('');
    $('#country_id').select2();
</script>
@endif
@stop