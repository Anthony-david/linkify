@extends('admin.layout.layout')
@section('style')
@stop
@section('content')
<div class="row">
<div class="col-md-12">
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
  <h5 style="color: red; text-align: center;"><b> Auto-sync is a pro <i class="fa">&#xf0e7;</i> feature. You need to <a href="#">upgrade</a> to enable it. </b></h5>
    <section class="panel panel-info">
        <header class="panel-heading">
            Auto-sync is <span style="color: red">Deactivated</span>
        </header>
      <div class="panel-body">
            <!-- <form class="form-horizontal" role="form"> -->
              <?=Form::model($auto_sync,['route' => 'admin.auto-sync.action', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal m-0'])?>

                <div class="form-group @if($errors->has('auto_sync_action')) {{ 'has-error' }} @endif">
                  <div class="col-md-2"></div>
                  <div class="col-md-8">
                    {!! Form::select('auto_sync_action', array(""=>"Select Action","1"=>"Quick Action"), null, ['class' => 'form-control full has-error','id' => 'auto_sync_action' ]) !!}
                    <span id="auto_sync_action" class="help-inline text-danger"><?=$errors->first('auto_sync_action')?></span>
                  </div>
                  <div class="col-md-2">
                      <button type="submit" class="btn btn-primary">Save</button>
                  </div>
                </div>
            <!-- </form> -->
            <?=Form::close()?>
        </div>
    </section>
    <!-- <section class="panel panel-info">
      <header class="panel-heading">
            For auto-sync to work you need to set Amazon Web Services Access Credentials
            <button type="submit" class="btn btn-danger"> Set AWS Credentials </button>
      </header>
    </section> -->
    <!-- <section class="panel panel-info">
      <header class="panel-heading">
          Auto-sync rules
          <a href="#">AWS Credentials</a>
      </header>
      <div class="panel-body">
          <?=Form::model($auto_sync,['route' => 'admin.auto-sync.credentials', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal m-0'])?>

              <div class="form-group @if($errors->has('product_price')) {{ 'has-error' }} @endif">
                <label class="col-md-4 control-label">Product Price changes</label>
                <div class="col-md-8">
                  {!! Form::select('product_price', array(""=>"Select Price Changes Event","1"=>"Update Price on Shopify as per Amazon","2"=>"ABC"), null, ['class' => 'form-control full has-error','id' => 'product_price' ]) !!}
                  <span id="product_price" class="help-inline text-danger"><?=$errors->first('product_price')?></span>
                </div>
              </div>

              <div class="form-group @if($errors->has('product_stock')) {{ 'has-error' }} @endif">
                <label class="col-md-4 control-label">Product goes out of stock</label>
                <div class="col-md-8">
                  {!! Form::select('product_stock', array(""=>"Select Product Stock","1"=>"Mark it as OUT OF STOCK","2"=>"ABC"), null, ['class' => 'form-control full has-error','id' => 'product_stock' ]) !!}
                  <span id="product_stock" class="help-inline text-danger"><?=$errors->first('product_stock')?></span>
                </div>
              </div>

              <div class="form-group @if($errors->has('discontinue_product')) {{ 'has-error' }} @endif">
                <label class="col-md-4 control-label">Product is discontinued</label>
                <div class="col-md-8">
                  {!! Form::select('discontinue_product', array(""=>"Select Product for remove","1"=>"Remove product from Shopify","2"=>"ABC"), null, ['class' => 'form-control full has-error','id' => 'discontinue_product' ]) !!}
                  <span id="discontinue_product" class="help-inline text-danger"><?=$errors->first('discontinue_product')?></span>
                </div>
              </div>
              <div class="col-lg-offset-6">
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
        <?=Form::close()?>
      </div>
    </section> -->
</div>
</div>
<!-- <div class="row">
<div class="col-md-12">
    <section class="panel panel-info">
        <header class="panel-heading">
            What is auto-sync?
        </header>
        <div class="panel-body">
          <p>Spreadr will auto update price & availability values to match Amazon so that your inventory and prices are always up to date. Spreadr auto-syncs once in every 24 hours. </p>
          <br>
          <p><a href="#">Auto-sync FAQs</a></p>
          <p><a href="#">Auto-sync rule guidelines</a></p>
        </div>
    </section>
</div>
</div> -->
@stop

@section('script')
  <?=Html::script('backend/js/select2.min.js', [], IS_SECURE)?>
  
  <script type="text/javascript">
    $(document).ready(function(){
      $('#auto_sync_action').select2({
          'placeholder':"Select auto_sync_actioning",
          allowClear: true
      });
      $('#product_price').select2({
          'placeholder':"Select Product Price",
          allowClear: true
      });
      $('#product_stock').select2({
          'placeholder':"Select Product Stock",
          allowClear: true
      });
      $('#discontinue_product').select2({
          'placeholder':"Select Product Stock",
          allowClear: true
      });
    });
  </script>    
@stop

