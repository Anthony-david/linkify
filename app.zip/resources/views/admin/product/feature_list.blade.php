@if(count($feature))
	<ul>
		@if(is_array($feature))
		    @foreach($feature as $key => $single)
		        <li><?= $single ?></li>
		    @endforeach
		@endif
	</ul>
@endif
@if(count($product_attribute))
	<table>
	    @foreach($product_attribute as $key => $single)
	    	<tr>
		        <td><?=$key?></td>
		        <td>
		            @if(is_array($single))
		              @foreach($single as $single_in)
		              	@if(!is_array($single_in))
		              		<?= $single_in ?>
		              	@endif
		              @endforeach
		            @else
		              <?= $single ?>
		            @endif
		        </td>
	    	</tr>
	    @endforeach
	</table>
@endif
 