@extends('admin.layout.layout')
@section('style')
@stop
@section('content')
<div class="row">
    <div class="col-md-12">
        @if(session()->has('message'))
        <div class="alert alert-success">
            {{ session()->get('message') }}
        </div>
        @endif
        <section class="panel panel-info">
            <header class="panel-heading">
                Enter Default values for adding new products
            </header>
            <div class="panel-body">
                <!-- <form class="form-horizontal" role="form"> -->
                <?=Form::model($default_value,['route' => 'admin.default-values.store', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal m-0'])?>  
                <div class="form-group ">
                    <label class="col-md-4 control-label">Select Country</label>
                    <div class="col-md-4 @if($errors->has('currency')) {{ 'has-error' }} @endif">
                        {!! Form::select('currency', Config::get('CountryCode'), old('currency'), ['class' => 'form-control full has-error','id' => 'currency' ]) !!}
                        <span id="currency_error" class="help-inline text-danger"><?=$errors->first('currency')?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="class col-md-4 control-label">Show on store</label>
                    <div class="col-md-4">
                        {!! Form::select('store', array(""=>"Select Visibility","1"=>"Visible","2"=>"InVisible"), null, ['class' => 'form-control full has-error','id' => 'store' ]) !!}
                        <span id="store" class="help-inline text-danger"><?=$errors->first('store')?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="product_type" class="col-md-4 control-label">Product Type</label>
                    <div class="col-md-4">
                        <?=Form::text('product_type', null, ['class' => 'form-control', 'placeholder' => 'Product Type']);?>
                        <span id="product_type_error" class="help-inline text-danger"><?=$errors->first('product_type')?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="vendor" class="col-md-4 control-label">
                        Vendor 
                    </label>
                    <div class="col-md-4">
                        <!-- <input type="checkbox" name="auto_fill" id="auto_fill" value="1" checked="checked"> -->
                        <input type="checkbox" name="auto_fill" id="auto_fill" @if (old('auto_fill') or (isset($default_value->auto_fill) and $default_value->auto_fill == 1)) checked="checked" @endif>Auto-fill from Amazon
                        <?=Form::text('vendor',null, ['class' => 'form-control', 'placeholder' => 'vendor','id' => 'vendor']);?>
                        <span id="vendor_error" class="help-inline text-danger"><?=$errors->first('vendor')?></span>
                    </div><br>
                    <h6>Know more</h6>
                </div>
                <div class="form-group">
                    <label for="to_tag" class="col-md-4 control-label">
                        Tags 
                    </label>
                    <div class="col-md-4">
                        {!! Form::select('tag[]',((isset($default_value->tag) and head($default_value->tag) != '') ? $default_value->tag : []), null, ['class' => 'form-control select2_2','id' => 'to_tag','multiple'=>'multiple']) !!}
                        <!-- <select class="select2_2 form-control" id="to_tag" name="tag[]" multiple="multiple" placeholder="Vintage,cotton,summer"></select>
                            </select> -->
                        <!-- <a href="#" id="advance_tag">Advanced auto-tagging</a> -->
                        <span id="tag_error" class="help-inline text-danger"><?=$errors->first('tag')?></span>
                    </div>
                    <h6>Saperate two tags with commas</h6>
                </div>
                <div class="form-group">
                    <label for="product_template_suffix" class="col-md-4 control-label">Product Template Suffix</label>
                    <div class="col-md-4">
                        <?=Form::text('template_suffix', null, ['class' => 'form-control', 'placeholder' => 'alternate']);?>
                        <span id="template_suffix_error" class="help-inline text-danger"><?=$errors->first('template_suffix')?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="quantity" class="col-md-4 control-label">
                        Quantity 
                    </label>
                    <div class="col-md-4">
                        <?=Form::number('quantity', null, ['class' => 'form-control', 'placeholder' => '3']);?>
                        <span id="quantity_error" class="help-inline text-danger"><?=$errors->first('quantity')?></span>
                    </div>
                    <h6>Default Inventory quantity</h6>
                </div>
                <div class="form-group">
                    <div class="col-lg-offset-6">
                        <button type="submit" class="btn btn-primary"><b>Save</b></button>
                    </div>
                </div>
                <!-- </form> -->
                <?=Form::close()?>
            </div>
        </section>
    </div>
</div>
<!-- <div class="row">
    <div class="col-md-6">
        <section class="panel panel-info detail_box">
            <header class="panel-heading">
                 Amazon to Shopify for dropshipping?
            </header>
            <div class="panel-body">
                <p>Add spreadr-hidden tag to the product. The 'Add to Cart' button will not be replced with 'View on Amazon' button.</p>
                <p><a href="#">Know more...</a></p>
            </div>
        </section>
    </div>
    <div class="col-md-6">
        <section class="panel panel-info detail_box">
            <header class="panel-heading">
                Shopify Sales Channel Support
            </header>
            <div class="panel-body">
               <p>Spreadr App currently does not support Facebook / Pinterest sales channel.</p>
            <p><a href="#">Know more...</a></p>
            </div>
        </section>
    </div>
</div> -->
@stop
@section('script')
<?=Html::script('backend/js/select2.min.js', [], IS_SECURE)?>
<script type="text/javascript">

    function setVendor()
    {
        if(($('#auto_fill').prop('checked')) == true)
        {
            $('#vendor').prop("readonly", true);
            $('#auto_fill').attr("checked","checked");
            $('#auto_fill').val("1");
            $('#test').val("1");
        }
        else{
    
            $('#vendor').prop("readonly", false);
            $('#auto_fill').removeAttr("checked");
            $('#auto_fill').val("0");
            $('#test').val("0");
        }
    }
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#advance_tag').hide();
        setVendor();
    });

    $("#auto_fill").change(function() {
        if(this.checked) {
            $('#vendor').prop("readonly", true);
    
            $('#auto_fill').attr("checked","checked");
            $('#auto_fill').val("1");
            $('#test').val("1");
        }else{
            $('#vendor').prop("readonly", false);
    
            $('#auto_fill').removeAttr("checked");
            $('#auto_fill').val("0");
            $('#test').val("0");
        }
    });
    var error_value = JSON.parse('<?=$errors?>');
    
    var check_value = jQuery.isEmptyObject(error_value);
    
    if(check_value == false)
    {
       setVendor();
    }
    $('#store').select2({
        'placeholder':"Select Visibility",
        allowClear: true
    });

    $('#currency').select2({
        'placeholder':"Select Country",
         allowClear: true
    });
</script>
<script type="text/javascript">
    var tag = $('#to_tag').select2({
        placeholder : "select tag"
    
    });
    
    @if(old('tag'))
    
    var old_tag = {!! json_encode(old('tag')) !!};
    
    tag.val(old_tag).trigger('change'); 
    
    $.each(old_tag,function(k,v){
    
        $("#to_tag").append($('<option>', {value: v, text: v}));
    
    });
    @endif
</script>   
<?=Html::script('backend/tag/js/form.demo.min.js', [], IS_SECURE)?> 

@stop