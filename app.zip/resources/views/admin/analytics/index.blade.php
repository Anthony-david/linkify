@extends('admin.layout.layout')
@section('style')
@stop
@section('content')

<div class="col-md-8">
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
  <h5 style="color: red; text-align: center;"><b> Analytics is a pro <i class="fa">&#xf0e7;</i> feature. You need to <button class="btn btn-primary">upgrade</button> to achieve it. </b></h5>
    <section class="panel panel-info">
      <header class="panel-heading">
          Click Tracking is <span style="color: red">Deactivated</span>
      </header>
      <div class="panel-body">
            <!-- <form class="form-horizontal" role="form"> -->
              <?=Form::open(['route' => 'admin.analytics.store', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal m-0'])?>

                <div class="form-group @if($errors->has('track')) {{ 'has-error' }} @endif">
                    <label class="col-md-4 control-label">Click Tracking</label>
                    <div class="col-md-4">
                      {!! Form::select('track', array(""=>"Select Tracking Visibility","1"=>"Activate","0"=>"Deactivate"), null, ['class' => 'form-control full has-error','id' => 'track' ]) !!}
                      <span id="track" class="help-inline text-danger"><?=$errors->first('track')?></span>
                  </div>
                </div>
                
                <div class="form-group">
                    <div class="col-lg-offset-10">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            <!-- </form> -->
            <?=Form::close()?>
      </div>
    </section>
    <section class="panel panel-info">
      <header class="panel-heading">
          Before activating Click Tracking you need to <a href="#"> enable Google Analytics </a> for your Shopify store.
      </header>
    </section>
</div>
<div class="col-md-2">
    <section class="panel panel-info">
        <div class="panel-body">
          <p><b>What is Click Tracking?</b></p>
          <p>Spreadr will help your track clicks on links / buttons on your website that take users to Amazon. Click tracking data will be available in your Google Analytics account dashboard. </p>
          <br>
          <p><a href="#">Click Tracking FAQs</a></p>
          <p><a href="#">View Click Tracking Data</a></p>
        </div>
    </section>
</div>
@stop

@section('script')
  <?=Html::script('backend/js/select2.min.js', [], IS_SECURE)?>
  
  <script type="text/javascript">
    $(document).ready(function(){
      $('#track').select2({
          'placeholder':"Select Tracking",
          allowClear: true
      });
    });
  </script>    
@stop

