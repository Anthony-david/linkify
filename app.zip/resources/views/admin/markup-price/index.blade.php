@extends('admin.layout.layout')
@section('style')
@stop
@section('content')
<div class="col-md-12">
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
  	<section class="panel panel-info">
      	<header class="panel-heading">
          	Setup Markup Pricing Rules
      	</header>
      <div class="panel-body">
          	<!-- <form class="form-horizontal" role="form"> -->
              <?=Form::model($markup_price,['route' => 'admin.markup-pricing.store', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal m-0'])?>	
                
                <div class="form-group @if($errors->has('new_product')) {{ 'has-error' }} @endif">
                    <label class="col-md-4 control-label">When adding new products</label>
                  	<div class="col-md-6">
	                    {!! Form::select('new_product', array(""=>"Select New Product","1"=>"Do not apply markup pricing","2"=>"Apply markup pricing"), null, ['class' => 'form-control full has-error','id' => 'new_product' ]) !!}
	                    <span id="new_product" class="help-inline text-danger"><?=$errors->first('new_product')?></span>
	                </div>
                </div>
                <hr>
              	<div class="form-group">
                  	<label for="amazon_multiplier_markup_price" class="col-md-2 control-label">Amazon Price</label>
                  	<div class="col-md-4">
                      	<?=Form::number('amazon_multiplier_price', null, ['class' => 'form-control', 'placeholder' => '1.00',"step"=>"0.01"]);?>
                        <span id="amazon_multiplier_price_error" class="help-inline text-danger"><?=$errors->first('amazon_multiplier_price')?></span>
                  	</div>
                  	<div class="col-md-4">
                      	<?=Form::number('amazon_markup_price', null, ['class' => 'form-control', 'placeholder' => '0.00',"step"=>"0.01"]);?>
                        <span id="amazon_markup_price_error" class="help-inline text-danger"><?=$errors->first('amazon_markup_price')?></span>
                  	</div>
                  	<p class="col-md-2"><h5>= Shopify Price</h5></p>
              	</div>
              	<p style="text-align: center;">Example: $10 * 1 + 0 = $10.00</p>

              	<div class="form-group">
                  	<label for="shopify_multiplier_markup_price" class="col-md-2 control-label">Shopify Price</label>
                  	<div class="col-md-4">
                      	<?=Form::number('shopify_multiplier_price', null, ['class' => 'form-control', 'placeholder' => '1.00',"step"=>"0.01"]);?>
                        <span id="shopify_multiplier_price_error" class="help-inline text-danger"><?=$errors->first('shopify_multiplier_price')?></span>
                  	</div>
                  	<div class="col-md-4">
                      	<?=Form::number('shopify_markup_price', null, ['class' => 'form-control', 'placeholder' => '0.00',"step"=>"0.01"]);?>
                        <span id="shopify_markup_price_error" class="help-inline text-danger"><?=$errors->first('shopify_markup_price')?></span>
                  	</div>
                  	<p class="col-md-2"><h5>= Compare at Price</p></h5>
              	</div>
              	<p style="text-align: center;">Example: $10 * 1 + 0 = $10.00</p>

              	<div class="form-group">
                  	<label for="cents_price" class="col-md-4 control-label">Assign cents to price</label>
                  	<div class="col-md-4">
                      	<?=Form::number('cents_price', null, ['class' => 'form-control', 'placeholder' => '49 (cents)',"step"=>"0.01"]);?>
                        <span id="cents_price_error" class="help-inline text-danger"><?=$errors->first('cents_price')?></span>
                  	</div>
              	</div>

              	<div class="form-group">
                  	<label for="cents_comp_price" class="col-md-4 control-label">Assign cents to compare price</label>
                  	<div class="col-md-4">
                      	<?=Form::number('cents_comp_price', null, ['class' => 'form-control', 'placeholder' => '99 (cents)',"step"=>"0.01"]);?>
                        <span id="cents_comp_price_error" class="help-inline text-danger"><?=$errors->first('cents_comp_price')?></span>
                  	</div>
              	</div>

              	<div class="form-group">
                  	<div class="col-lg-offset-6">
                      	<button type="submit" class="btn btn-primary"><b>Save</b></button>
                  	</div>
              	</div>
          	<!-- </form> -->
            <?=Form::close()?>
      	</div>
  	</section>
</div>
<!-- <div class="row">
    <div class="col-md-6">
        <section class="panel panel-info detail_box">
            <header class="panel-heading">
                 Markup Pricing
            </header>
            <div class="panel-body">
                <p>You can setup rules to add margin / markup to the products you import from Amazon.</p>
          <p><a href="#">Markup Pricing FAQs</a></p> 
            </div>
        </section>
    </div>
    <div class="col-md-6">
        <section class="panel panel-info detail_box">
            <header class="panel-heading" style="height:43px;">
                
            </header>
            <div class="panel-body">
               <p>Stores with Amazon affiliate only products ignore this settings page Apply Markup Pricing only if you dropship Amazon products.</p>
            </div>
        </section>
    </div>
</div> -->
@stop

@section('script')
    <?=Html::script('backend/js/select2.min.js', [], IS_SECURE)?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#country').select2({
		    'placeholder':"Select Country",
		    allowClear: true
		});
	});
</script>    
@stop

