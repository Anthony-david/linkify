@extends('frontend.layout.layout')
@section('css')
<?= Html::style('frontend/css/reset.css',[],IS_SECURE) ?>
<?= Html::style('frontend/css/style.css',[],IS_SECURE) ?>
<?= Html::script('frontend/js/modernizr.js',[],IS_SECURE) ?>
@stop
@section('content')
<h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-2" style="padding:10% 0% 0% 0%;">
	Privacy Policy
</h2>
<section style="padding:0% 5%;">
	<p><span style="font-weight: 400;"><span class="b">Linkify Softwares & Applications </span>(&ldquo;we&rdquo; or &ldquo;us&rdquo; or &ldquo;our&rdquo;) respects the privacy of our users (&ldquo;user&rdquo; or &ldquo;you&rdquo;). This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our mobile application (the &ldquo;Application&rdquo;). Please read this Privacy Policy carefully. IF YOU DO NOT AGREE WITH THE TERMS OF THIS PRIVACY POLICY, PLEASE DO NOT ACCESS THE APPLICATION.</span></p>
	<br>
	<p><span style="font-weight: 400;">We reserve the right to make changes to this Privacy Policy at any time and for any reason. We will alert you about any changes by updating the &ldquo;Last updated&rdquo; date of this Privacy Policy. You are encouraged to periodically review this Privacy Policy to stay informed of updates. You will be deemed to have been made aware of, will be subject to, and will be deemed to have accepted the changes in any revised Privacy Policy by your continued use of the Application after the date such revised Privacy Policy is posted. &nbsp;</span></p>
	<br>
	<p><span style="font-weight: 400;">This Privacy Policy does not apply to the third-party online/mobile store from which you install the Application or make payments, including any in-game virtual items, which may also collect and use data about you. &nbsp;We are not responsible for any of the data collected by any such third party. </span></p>
	<br>
	<p><strong><span class="b">COLLECTION OF YOUR INFORMATION</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We may collect information about you in a variety of ways. The information we may collect via the Application depends on the content and materials you use, and includes: &nbsp;&nbsp;</span></p>
	<br>
	<p><strong><span class="b">Personal Data</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">Demographic and other personally identifiable information (such as your name and email address) that you voluntarily give to us when choosing to participate in various activities related to the Application, such as chat, posting messages in comment sections or in our forums, liking posts, sending feedback, and responding to surveys. If you choose to share data about yourself via your profile, online chat, or other interactive areas of the Application, please be advised that all data you disclose in these areas is public and your data will be accessible to anyone who accesses the Application. &nbsp;&nbsp;</span></p>
	<br>
	<p><strong><span class="b">Derivative Data</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">Information our servers automatically collect when you access the Application, such as your native actions that are integral to the Application, including liking, re-blogging, or replying to a post, as well as other interactions with the Application and other users via server log files. </span></p>
	<br>
	<p><strong><span class="b">Financial Data</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">Financial information, such as data related to your payment method (e.g. valid credit card number, card brand, expiration date) that we may collect when you purchase, order, return, exchange, or request information about our services from the Application. We store only very limited, if any, financial information that we collect. Otherwise, all financial information is stored by our payment processor, Paddle, and you are encouraged to review their privacy policy and contact them directly for responses to your questions. &nbsp;</span></p>
	<br>
	<p><strong><span class="b">USE OF YOUR INFORMATION</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">• Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information  collected about you via the Application to: </span></p>
	<ul>
		<li><span style="font-weight: 400;">• Compile anonymous statistical data and analysis for use internally or with third parties. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Create and manage your account. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Deliver targeted advertising, coupons, newsletters, and promotions, and other information regarding the Application to you. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Email you regarding your account or order. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Fulfill and manage purchases, orders, payments, and other transactions related to the Application. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Generate a personal profile about you to make future visits to the Application more personalized. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Increase the efficiency and operation of the Application. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Monitor and analyze usage and trends to improve your experience with the Application. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Notify you of updates to the Application. &nbsp;</span></li>
		<li><span style="font-weight: 400;">M Offer new products, services, mobile applications, and/or recommendations to you. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Perform other business activities as needed. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Request feedback and contact you about your use of the Application. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Resolve disputes and troubleshoot problems. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Respond to product and customer service requests. &nbsp;</span></li>
		<li><span style="font-weight: 400;">• Send you a newsletter. &nbsp;</span></li>
	</ul>
	<br>
	<p><strong><span class="b">DISCLOSURE OF YOUR INFORMATION</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We may share information we have collected about you in certain situations. Your information may be disclosed as follows:</span></p>
	<br>
	<p><strong><span class="b">By Law or to Protect Rights</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we may share your information as permitted or required by any applicable law, rule, or regulation. This includes exchanging information with other entities for fraud protection and credit risk reduction. &nbsp;</span></p>
	<br>
	<p><strong><span class="b">Third-Party Service Providers</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We may share your information with third parties that perform services for us or on our behalf, including payment processing, data analysis, email delivery, hosting services, customer service, and marketing assistance. &nbsp;</span></p>
	<br>
	<p><strong><span class="b">Marketing Communications</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">With your consent, or with an opportunity for you to withdraw consent, we may share your information with third parties for marketing purposes, as permitted by law. &nbsp;</span></p>
	<br>
	<p><strong><span class="b">Third-Party Advertisers</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We may use third-party advertising companies to serve ads when you visit the Application. These companies may use information about your visits to the Application and other websites that are contained in web cookies in order to provide advertisements about goods and services of interest to you.</span></p>
	<br>
	<p><strong><span class="b">Business Partners<</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We may share your information with our business partners to offer you certain products, services or promotions.</span></p>
	<br>
	<p><strong><span class="b">Offer Wall</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">The Application may display a third-party hosted &ldquo;offer wall.&rdquo; Such an offer wall allows third-party advertisers to offer virtual currency, gifts, or other items to users in return for acceptance and completion of an advertisement offer. Such an offer wall may appear in the Application and be displayed to you based on certain data, such as your geographic area or demographic information. When you click on an offer wall, you will leave the Application. A unique identifier, such as your user ID, will be shared with the offer wall provider in order to prevent fraud and properly credit your account. </span></p>
	<br>
	<p><strong><span class="b">Other Third Parties</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We may share your information with advertisers and investors for the purpose of conducting general business analysis. We may also share your information with such third parties for marketing purposes, as permitted by law.</span></p>
	<br>
	<p><strong><span class="b">Sale or Bankruptcy</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">If we reorganize or sell all or a portion of our assets, undergo a merger, or are acquired by another entity, we may transfer your information to the successor entity. &nbsp;If we go out of business or enter bankruptcy, your information would be an asset transferred or acquired by a third party. You acknowledge that such transfers may occur and that the transferee may decline honor commitments we made in this Privacy Policy. We are not responsible for the actions of third parties with whom you share personal or sensitive data, and we have no authority to manage or control third-party solicitations. If you no longer wish to receive correspondence, emails or other communications from third parties, you are responsible for contacting the third party directly. </span></p>
	<br>
	<p><strong><span class="b">TRACKING TECHNOLOGIES</span></strong><span style="font-weight: 400;"> &nbsp;&nbsp;</span></p>
	<br>
	<p><strong><span class="b">Cookies and Web Beacons </span></strong><span style="font-weight: 400;">&nbsp;&nbsp;</span></p>
	<br>
	<p><span style="font-weight: 400;">We may use cookies, web beacons, tracking pixels, and other tracking technologies on the Application to help customize the Application and improve your experience. When you access the Application, your personal information is not collected through the use of tracking technology. Most browsers are set to accept cookies by default. You can remove or reject cookies, but be aware that such action could affect the availability and functionality of the Application. You may not decline web beacons. However, they can be rendered ineffective by declining all cookies or by modifying your web browser&rsquo;s settings to notify you each time a cookie is tendered, permitting you to accept or decline cookies on an individual basis.</span> <span style="font-weight: 400;">&nbsp;&nbsp;</span></p>
	<br>
	<p><strong><span class="b">Internet-Based Advertising</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">Additionally, we may use third-party software to serve ads on the Application, implement email marketing campaigns, and manage other interactive marketing initiatives. This third-party software may use cookies or similar tracking technology to help manage and optimize your online experience with us. For more information about opting-out of interest-based ads, visit the </span><a href="https://developers.facebook.com/docs/facebook-login/permissions"><span style="font-weight: 400;">Network Advertising Initiative Opt-Out Tool</span></a> <span style="font-weight: 400;">or </span><a href="http://www.aboutads.info/choices/"><span style="font-weight: 400;">Digital Advertising Alliance Opt-Out Tool</span></a><span style="font-weight: 400;">. &nbsp;</span></p>
	<br>
	<p><strong><span class="b">Website Analytics</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We may also partner with selected third-party vendors, such as Google Analytics, to allow tracking technologies and remarketing services on the Application through the use of first party cookies and third-party cookies, to, among other things, analyze and track users&rsquo; use of the Application, determine the popularity of certain content, and better understand online activity. By accessing the Application, you consent to the collection and use of your information by these third-party vendors. You are encouraged to review their privacy policy and contact them directly for responses to your questions. We do not transfer personal information to these third-party vendors. However, if you do not want any information to be collected and used by tracking technologies, you can visit the third-party vendor or </span><a href="https://developers.facebook.com/docs/facebook-login/permissions"><span style="font-weight: 400;">Network Advertising Initiative Opt-Out Tool</span></a><span style="font-weight: 400;"> or </span><a href="http://www.aboutads.info/choices/"><span style="font-weight: 400;">Digital Advertising Alliance Opt-Out Tool</span></a><span style="font-weight: 400;">.</span></p>
	<br>
	<p><span style="font-weight: 400;">You should be aware that getting a new computer, installing a new browser, upgrading an existing browser, or erasing or otherwise altering your browser&rsquo;s cookies files may also clear certain opt-out cookies, plug-ins, or settings. </span></p>
	<br>
	<p><strong><span class="b">THIRD-PARTY WEBSITES</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">The Application may contain links to third-party websites and applications of interest, including advertisements and external services, that are not affiliated with us. Once you have used these links to leave the Application, any information you provide to these third parties is not covered by this Privacy Policy, and we cannot guarantee the safety and privacy of your information. Before visiting and providing any information to any third-party websites, you should inform yourself of the privacy policies and practices (if any) of the third party responsible for that website, and should take those steps necessary to, in your discretion, protect the privacy of your information. We are not responsible for the content or privacy and security practices and policies of any third parties, including other sites, services or applications that may be linked to or from the Application. </span></p>
	<br>
	<p><strong><span class="b">SECURITY OF YOUR INFORMATION</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse. Any information disclosed online is vulnerable to interception and misuse by unauthorized parties. Therefore, we cannot guarantee complete security if you provide personal information. </span></p>
	<br>
	<p><strong><span class="b">POLICY FOR CHILDREN</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">We do not knowingly solicit information from or market to children under the age of 13. If you become aware of any data we have collected from children under age 13, please contact us using the contact information provided below. </span></p>
	<br>
	<p><strong><span class="b">CONTROLS FOR DO-NOT-TRACK FEATURES</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">Most web browsers and some mobile operating systems include a Do-Not-Track (&ldquo;DNT&rdquo;) feature or setting you can activate to signal your privacy preference not to have data about your online browsing activities monitored and collected. &nbsp;No uniform technology standard for recognizing and implementing DNT signals has been finalized. As such, we do not currently respond to DNT browser signals or any other mechanism that automatically communicates your choice not to be tracked online. If a standard for online tracking is adopted that we must follow in the future, we will inform you about that practice in a revised version of this Privacy Policy. &nbsp;</span></p>
	<br>
	<p><strong><span class="b">OPTIONS REGARDING YOUR INFORMATION</span></strong></p>
	<br>
	<p><strong><span class="b">Account Information</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">You may at any time review or change the information in your account or terminate your account by: </span></p>
	<ul>
		<li><span style="font-weight: 400;"> Contacting us using the contact information provided. &nbsp;&nbsp;</span></li>
	</ul>
	<br>
	<p><span style="font-weight: 400;">Upon your request to terminate your account, we will deactivate or delete your account and information from our active databases. However, some information may be retained in our files to prevent fraud, troubleshoot problems, assist with any investigations, enforce our Terms of Use and/or comply with legal requirements.</span></p>
	<br>
	<p><strong><span class="b">Emails and Communications</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">If you no longer wish to receive correspondence, emails, or other communications from us, you may opt-out by: </span></p>
	<br>
	<p><span style="font-weight: 400;">If you no longer wish to receive correspondence, emails, or other communications from third parties, you are responsible for contacting the third party directly.</span></p>
	<br>
	<p><strong><span class="b">CALIFORNIA PRIVACY RIGHTS</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">California Civil Code Section 1798.83, also known as the &ldquo;Shine The Light&rdquo; law, permits our users who are California residents to request and obtain from us, once a year and free of charge, information about categories of personal information (if any) we disclosed to third parties for direct marketing purposes and the names and addresses of all third parties with which we shared personal information in the immediately preceding calendar year. If you are a California resident and would like to make such a request, please submit your request in writing to us using the contact information provided below.</span></p>
	<br>
	<p><span style="font-weight: 400;">If you are under 18 years of age, reside in California, and have a registered account with the Application, you have the right to request removal of unwanted data that you publicly post on the Application. To request removal of such data, please contact us using the contact information provided below, and include the email address associated with your account and a statement that you reside in California. &nbsp;We will make sure the data is not publicly displayed on the Application, but please be aware that the data may not be completely or comprehensively removed from our systems.</span></p>
	<br>
	<p><strong><span class="b">CONTACT US</span></strong></p>
	<br>
	<p><span style="font-weight: 400;">If you have questions about this Privacy Policy and for any requests for data access, portability or erasure please contact us at:</span></p>
	<br><br><br>
</section>
@stop
@section('js')
<?= Html::script('frontend/js/jquery-2.1.1.js',[],IS_SECURE) ?>
<?= Html::script('frontend/js/jquery.mobile.custom.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/js/main.js',[],IS_SECURE) ?>
@stop