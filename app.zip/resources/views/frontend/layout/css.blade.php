<?= Html::style('frontend/assets/web/assets/linkify-icons-bold/linkify-icons-bold.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/web/assets/linkify-icons/linkify-icons.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/tether/tether.min.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/bootstrap/css/bootstrap.min.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/bootstrap/css/bootstrap-grid.min.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/bootstrap/css/bootstrap-reboot.min.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/socicon/css/styles.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/dropdown/css/style.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/theme/css/style.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/fonts/style.css',[],IS_SECURE) ?>
<?= Html::style('frontend/assets/linkify/css/mbr-additional.css',[],IS_SECURE) ?>
@yield('css')