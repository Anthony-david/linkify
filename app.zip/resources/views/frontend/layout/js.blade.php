<section class="cid-qSowLG1u9s" id="footer1-15">
	<div class="container" id="contactus">
		<div class="media-container-row content text-white">
			<div class="col-12 col-md-3">
				<div class="media-wrap">
					<a href="https://mylinkify.com/">
						<img src="<?= URL_PATH ?>frontend/assets/images/linkifylogo-122x122.png" alt="Linkify Logo" title="">
					</a>
				</div>
			</div>
			<div class="col-12 col-md-3 mbr-fonts-style display-4">
				<h5 class="pb-3">
					Address
				</h5>
				<p class="mbr-text"><span style="font-size: 1.25rem;">69 Kearny Ave,</span><span style="font-size: 1.25rem;"><br></span>Kearny, NJ 07032,<br>USA</p>
			</div>
			<div class="col-12 col-md-3 mbr-fonts-style display-4">
				<h5 class="pb-3">
					Contacts
				</h5>
				<p class="mbr-text">
					Email: support@linkify.freshdesk.com
					<br><br>
				</p>
			</div>
			<div class="col-12 col-md-3 mbr-fonts-style display-7">
				<h5 class="pb-3">
					Links
				</h5>
				<p class="mbr-text"><a class="text-primary" href="https://mylinkify.com/privacy">Privacy Policy</a><br><a class="text-primary" href="https://mylinkify.com/terms">Terms of Use</a>&nbsp;<br><br></p>
			</div>
		</div>
		<div class="footer-lower">
			<div class="media-container-row">
				<div class="col-sm-12">
					<hr>
				</div>
			</div>
			<div class="media-container-row mbr-white">
				<div class="col-sm-6 copyright">
					<p class="mbr-text mbr-fonts-style display-7">
						© Copyright 2018 Linkify - All Rights Reserved
					</p>
				</div>
				<div class="col-md-6">
					<div class="social-list align-right">
						<div class="soc-item">
							<a href="#" target="_blank">
								<span class="socicon-twitter socicon mbr-iconfont mbr-iconfont-social"></span>
							</a>
						</div>
						<div class="soc-item">
							<a href="#" target="_blank">
								<span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social"></span>
							</a>
						</div>
						<div class="soc-item">
							<a href="#" target="_blank">
								<span class="socicon-youtube socicon mbr-iconfont mbr-iconfont-social"></span>
							</a>
						</div>
						<div class="soc-item">
							<a href="#" target="_blank">
								<span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"></span>
							</a>
						</div>
						<div class="soc-item">
							<a href="#" target="_blank">
								<span class="socicon-googleplus socicon mbr-iconfont mbr-iconfont-social"></span>
							</a>
						</div>
						<div class="soc-item">
							<a href="#" target="_blank">
								<span class="socicon-behance socicon mbr-iconfont mbr-iconfont-social"></span>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?= Html::script('frontend/assets/web/assets/jquery/jquery.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/popper/popper.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/tether/tether.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/bootstrap/js/bootstrap.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/touchswipe/jquery.touch-swipe.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/parallax/jarallax.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/viewportchecker/jquery.viewportchecker.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/smoothscroll/smooth-scroll.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/dropdown/js/script.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/assets/theme/js/script.js',[],IS_SECURE) ?>