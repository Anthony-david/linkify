@extends('frontend.layout.layout')
@section('content')
<section class="engine"><a href="https://mylinkify.com">simple website builder</a></section>
<section class="cid-qQRDVDgbcx mbr-fullscreen mbr-parallax-background" id="header2-w">
	<div class="container align-center">
		<div class="row justify-content-md-center">
			<div class="mbr-white col-md-10">
				<h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-2">Import Products from Amazon</h1>
				<p class="mbr-text pb-3 mbr-fonts-style display-5">
					Use Linkify App to Import Amazon products from Amazon to Shopify. You can use the App for Amazon Affiliate and Dropshipping Bussiness.&nbsp;<br><br>
				</p>
				<div class="mbr-section-btn"><a class="btn btn-md btn-primary display-4" href="https://mylinkify.com">Get Linkify App Shopify</a>
					<a class="btn btn-md btn-secondary display-4" href="https://mylinkify.com">View App Features</a>
				</div>
			</div>
		</div>
	</div>
	<div class="mbr-arrow hidden-sm-down" aria-hidden="true">
		<a href="#next">
			<i class="mbri-down mbr-iconfont"></i>
		</a>
	</div>
</section>
<section class="header7 cid-qQS3oT0uTl" id="header7-z">
	<div class="container">
		<div class="media-container-row">
			<div class="media-content align-right">
				<h1 class="mbr-section-title mbr-white pb-3 mbr-fonts-style display-2">Why use Linkify App?&nbsp;</h1>
				<div class="mbr-section-text mbr-white pb-3">
					<p class="mbr-text mbr-fonts-style display-7">- 1 click product import from Amazon to your Shopify store.<br>- No More washing time on uploading products to your store.<br>-Linkiky is designed in a very simple format so that even Non-technical user can use. &nbsp;--&gt; Watch the Video --&gt;</p>
				</div>
				<div class="mbr-section-btn"><a class="btn btn-md btn-primary display-4" href="https://mylinkify.com">Amazon Affiliate</a>
					<a class="btn btn-md btn-secondary display-4" href="https://mylinkify.com">Dropshipping</a>
				</div>
			</div>
			<div class="mbr-figure" style="width: 100%;"><iframe width="560" height="315" src="https://www.youtube.com/embed/0jvBHZr_-XM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
		</div>
	</div>
</section>
<section class="counters1 counters cid-qQSrhYjHic" id="counters1-10">
	<div class="container">
		<h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-2">
			Amazon Affiliate and Dropshipping Features
		</h2>
		<h3 class="mbr-section-subtitle mbr-fonts-style display-5">Shopify App to import products and save your Precious Time</h3>
		<div class="container pt-4 mt-2">
			<div class="media-container-row">
				<div class="card p-3 align-center col-12 col-md-6">
					<div class="panel-item p-3">
						<div class="card-text">
							<h3 class="count pt-3 pb-3 mbr-fonts-style display-2" style="display:none;"></h3>
							<h4 class="mbr-content-title mbr-bold mbr-fonts-style display-7">
								Amazon Affiliate Features
							</h4>
							<p class="mbr-content-text mbr-fonts-style display-7">► 1 click product Import<br>► Auto Inventory and Price Sync&nbsp;<br>► Auto Affiliate link Generator<br>► "Add to Cart" changes to "View on Amazon" <br>&nbsp; &nbsp; &nbsp;or Both&nbsp;<br><br>Click here to see video Tutorial for Amazon Affiliate</p>
						</div>
					</div>
				</div>
				<div class="card p-3 align-center col-12 col-md-6">
					<div class="panel-item p-3">
						<div class="card-text">
							<h3 class="count pt-3 pb-3 mbr-fonts-style display-2" style="display:none;"></h3>
							<h4 class="mbr-content-title mbr-bold mbr-fonts-style display-7">
								Dropshipping Features
							</h4>
							<p class="mbr-content-text mbr-fonts-style display-7">► 1 Click Product Import &nbsp;&nbsp;<br>► Markup Price<br>► Real Products Pages<br>► Only "Add to Cart"<br><br><br>Click here to see video Tutorial for Dropshipping<br><br></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
@stop