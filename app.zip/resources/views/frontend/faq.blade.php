@extends('frontend.layout.layout')
@section('css')
<?= Html::style('frontend/css/reset.css',[],IS_SECURE) ?>
<?= Html::style('frontend/css/style.css',[],IS_SECURE) ?>
<?= Html::script('frontend/js/modernizr.js',[],IS_SECURE) ?>
@stop
@section('content')
<h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-2" style="padding:10% 0% 0% 0%;">
	FAQ
</h2>
<section class="cd-faq">
	<ul class="cd-faq-categories">
		<li><a class="selected" href="#installation">Installation</a></li>
		<li><a href="#howitworks">How it works</a></li>
		<li><a href="#account">Account</a></li>
		<li><a href="#settings">Settings</a></li>
		<li><a href="#affiliate">Amazon - Affiliates</a></li>
		<li><a href="#sync">Product-Sync</a></li>
		<li><a href="#markup">MarkUp Price</a></li>
	</ul>
	<!-- cd-faq-categories -->
	<div class="cd-faq-items">
		<ul id="installation" class="cd-faq-group">
			<br>
			<li class="cd-faq-title">
				<h2>Installation</h2>
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Installation Steps</a>
				<div class="cd-faq-content">
					<p>Installing Linkify App is simple and takes only few minutes.<br><br>
						To install, visit the <a href="https://apps.shopify.com/" target="blank">Shopify appstore</a> and click <span class="b">Get App</span>. <br>
						1. You will be prompted to log in to your Shopify store and then approve the installation. Approx time - 2mins<br>
						2. This <a href="" target="blank">Guide</a> will walk you through the simple process of integrating the Linkify App into your Shopify site. Approx time - 5mins<br>
						3. Join <a href="https://affiliate-program.amazon.com/" target="blank">Amazon Associates Program </a>- its free. Get your Amazon Affiliate ID and save it in the settings section of this dashboard. Approx time - 5mins<br>
						4. Done. Start adding Amazon products to your store by simply pasting the Amazon product page URL in the app dashboard.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Integrating Linkify App*</a>
				<div class="cd-faq-content">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi cupiditate et laudantium esse adipisci consequatur modi possimus accusantium vero atque excepturi nobis in doloremque repudiandae soluta non minus dolore voluptatem enim reiciendis officia voluptates, fuga ullam? Voluptas reiciendis cumque molestiae unde numquam similique quas doloremque non, perferendis doloribus necessitatibus itaque dolorem quam officia atque perspiciatis dolore laudantium dolor voluptatem eligendi? Aliquam nulla unde voluptatum molestiae, eos fugit ullam, consequuntur, saepe voluptas quaerat deleniti. Repellendus magni sint temporibus, accusantium rem commodi?</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">How do I uninstall Linkify?</a>
				<div class="cd-faq-content">
					<p>You can uninstall Linkify app through your Shopify store admin.<br> <br>
						1. Go to your Shopify admin. <br>
						2. Go to 'Apps'. When the page loads, click on the image of the garbage bin next to the Linkify app.<br>
						Image Here ......................................<br>
						That's it! The app is now uninstalled. <br>
						For detailed instructions check out <a href="https://help.shopify.com/manual/apps/working-with-apps#uninstall-an-app" target="blank">Shopify guide to uninstall app.</a>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
		</ul>
		<!-- cd-faq-group -->
		<ul id="howitworks" class="cd-faq-group">
			<li class="cd-faq-title">
				<h2>How it Works</h2>
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Who is this app for?</a>
				<div class="cd-faq-content">
					<p>Linkify app enables Shopify store owners to import Amazon products into their store.<br><br>
						It is a simple yet powerful tool which is for - <br><br>
						1. Shopify store owners to make extra money via <span class="b">Amazon Affiliate Program.</span> <a href="" target="">Know more.</a><br>
						2. Shopify store owners - that are using Amazon as their main <span class="b">drop-shipping </span> source - to effortlessly import products into their Shopify store.<a href="" target="blank"> Know more.</a><br>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Linkify App with Amazon Affiliate Program - How it works?
				</a>
				<div class="cd-faq-content">
					<p>Shopify store owners can use Linkify to make extra money via Amazon Affiliate Program.<br>
						<br>
						How it works:<br><br>
						1. Install Linkify App.<br>
						2. Import complementary products from Amazon to your store via Linkify App.<br>
						3. Each imported product has a <span class="b"> View on Amazon</span> button instead on <span class="b">Add to cart</span> button. <br>
						4. Clicking this button your users are taken to Amazon site. <br>
						5. They buy the product and Amazon fulfills the order. <br>
						6. You get paid commission for all the sales generated via your referred customer. <br>
						7. Important - you need to signup for <a href="https://affiliate-program.amazon.com/" target="blank">Amazon Affiliate Program</a> and save the affiliate ID in the settings section of Linkify dashboard.<br>
						8. Amazon will transfer the payment to your account as per the settings in your Amazon Affiliate Program Account.<br>
						<br>
						Most of the Linkify App users use this option to generate additional revenue to complement their existing source.<br>
						<br>
						* If a visitor to your site buys something from Amazon within<span class="b"> 24 hours </span>of clicking on your affiliate link, you will get a commission. You get commissions for every single item they buy - not just the ones you promote and link out to. i.e you will make money every time someone clicks on one of your links and purchases <span class="b">anything </span> from Amazon.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Linkify App for Dropshipping - How it works?
				</a>
				<div class="cd-faq-content">
					<p>Sellers who use Amazon as their main dropshipping source can use Linkify to effortlessly import products to their Shopify store.<br>
						<br>
						How it works?<br>
						<br>
						1. Install Linkify App.<br>
						2. Import products from Amazon to your store via Linkify App.<br>
						3. Markup the product price via Shopify admin.<br>
						4. Here you do not linkout (redirect) your customers to Amazon.<br>
						5. Customers place the order on your site and you have to fulfill it.<br>
						6. It is like selling a regular product on your site - you get the payment. <br>
						7. Amazon is not the drop-shipper. You are responsible for sourcing the products and delivering to your customers. You have to provide customer service.<br>
						<br>
						This option is best suited for people who sell products on Amazon to also have them on their Shopify website. <br>
						<br>
						We do not recommend drop-shipping for those who are looking to place manual order on Amazon in response to their customers placing an order on Shopify site. It leads to fulfillment, customer service and IP issues.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">How to add Amazon products to my Shopify store?
				</a>
				<div class="cd-faq-content">
					<p>
						1. Browse Amazon for the product you want to add to Shopify<br>
						Add Image -------------------------------------<br>
						2. Copy product URL<br>
						3. Paste the product URL in your Linkify Dashboard<br>
						Add Image ---------------------------------<br>
						4. Click 'Add product'<br>
						<br>
						Linkify fetches product info from official Amazon API and the product gets added to your shopify store.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Can I use Linkify for dropshipping?</a>
				<div class="cd-faq-content">
					<p>
						Sellers who use Amazon as their main dropshipping source can use Linkify to effortlessly import products to their Shopify store.<br>
						<br>
						How it works?<br>
						<br>
						1. Install Linkify App.<br>
						2. Import products from Amazon to your store via Linkify App.<br>
						3. Here you do not linkout (redirect) your customers to Amazon.<br>
						4. Customers place the order on your site and you have to fulfill it.<br>
						5. It is like selling a regular product on your site - you get the payment.<br> 
						6. Amazon is not the drop-shipper. You are responsible for sourcing the products and delivering to your customers. You have to provide customer service.<br>
						<br>
						This option is best suited for people who sell products on Amazon to also have them on their Shopify website. <br>
						<br>
						We do not recommend drop-shipping for those who are looking to place manual order on Amazon in response to their customers placing an order on Shopify site. It leads to fulfillment, customer service and IP issues.<br>
						<br>
						In order to enable dropshipping - just add a tag called <span class="b">linkify-hidden</span> to any product you want to dropship. 'Add to cart' button will not be replaced with 'View on Amazon' button.<br>
						<br>
						You can also add <span class="b">linkify-hidden</span> tag by default to all products you import from Amazon via Shopify. To do this simply, go to Dashboard --> Settings --> Default Values and add <span class="b">linkify-hidden</span> in the Tags input box.<br>
						<br>
						Detailed instructions on how to add <span class="b">linkify-hidden</span> tag can be found here.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Can I use Linkify for both - Amazon Affiliate and Dropshipping?
				</a>
				<div class="cd-faq-content">
					<p>
						Yes, you can.<br>
						<br>
						By default all the products imported via Linkify App will have 'View on Amazon' button instead on 'Add to Cart' button. Clicking on this button redirects the user to Amazon product page. Shopify store owners get commissions for sales generated via Amazon Affiliate Program.<br>
						<br>
						In order to enable dropshipping - just add a tag called <span class="b">linkify-hidden</span> to any product you want to dropship. 'Add to cart' button will not be replaced with 'View on Amazon' button. Customers will be able to do a regular Shopify checkout.
						<br>
						Detailed instructions on how to add <span class="b">linkify-hidden</span> tag can be found here.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
		</ul>
		<!-- cd-faq-group -->
		<ul id="account" class="cd-faq-group">
			<li class="cd-faq-title">
				<h2>Account</h2>
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">How will I be charged?
				</a>
				<div class="cd-faq-content">
					<p>
						Linkify charges you via Shopify billing API meaning that charges appear directly on your Shopify invoice. <br>
						<br>
						Click <a href="" target="blank">here</a> to know about our pricing plans.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">What are the different pricing plans?</a>
				<div class="cd-faq-content">
					<p>You can try Linkify App free for 3 days. <br>
						<br>
						<span class="b">Linkify Welcome Offer Just $5 &nbsp;<s>$10</s>.</span><br>
						<br>
						•There are no setup fees on any of our plans. <br>
						•Cancel the account anytime by simply uninstalling the app.<br>
						•You can upgrade or downgrade your plan at any time.<br>
						•To keep it fair and transparent for everyone we do not offer discounts on any of the plans to anyone.<br>
						•The app charges appear directly on your Shopify invoice – you don't have to input your credit card information again to use our app.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Can I cancel my subscription any time?
				</a>
				<div class="cd-faq-content">
					<p>
						<br>
						Yes, you can cancel any time by uninstalling Linkify App from your store. Your subscription will be cancelled and no further payments taken.<br>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Does Linkify support installation on more than one store?
				</a>
				<div class="cd-faq-content">
					<p> <br>
						Linkify App is specific to a single store. If you have a another store you'd like to use Linkify, just install the app again for each additional store.
						<br>
						Image to be uploaded --------------------------------
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Which Shopify sales channels does Linkify support?
				</a>
				<div class="cd-faq-content">
					<p> <br>
						Currently, we only support "Online store" sales channel. There is no way for users to be redirected to Amazon when clicking on a product on Facebook shop or any other sales channel (apart from "Online store").<br>
						<br>
						If you are using other sales channels such as Facebook, Pinterest you will have to disable visibility for all the Linkify imported products for those sales channels.<br>
						Image to be uploaded --------------------------------
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Does Linkify support Facebook / Pinterest store sales channel?
				</a>
				<div class="cd-faq-content">
					<p> <br>
						Linkify App currently does not support Facebook / Pinterest channel. There is no way for users to be redirected to Amazon when clicking on a product on Facebook shop or Pinterest pin.<br>
						<br>
						You will have to disable Facebook / Pinterest visibility for all the products imported via Linkify.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">What happens to Amazon products when Linkify is uninstalled?
				</a>
				<div class="cd-faq-content">
					<p> <br>
						If you uninstall / remove Linkify app the existing products imported via Linkify continue to work normally (provided you do not remove the Linkify integration code manually.) Products will continue to link out to Amazon and you will get affiliate commissions for generated sales.<br>
						<br>
						Certain features such as Auto-sync, Customer Reviews will not work.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
		</ul>
		<!-- cd-faq-group -->
		<ul id="settings" class="cd-faq-group">
			<li class="cd-faq-title">
				<h2>Settings</h2>
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">How will Amazon products be displayed on my store?</a>
				<div class="cd-faq-content">
					<p>
						<br>Amazon products will look the same as your regular products - according to your installed theme.<br>
						<br>
						The only difference - 'Add to cart' button will be replaced with 'View on Amazon' button. You can change the text on the Amazon button.<br>
						Image to be Uploaded---------------------------
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Can I change Amazon product information?
				</a>
				<div class="cd-faq-content">
					<p>
						Once you add Amazon product to your Shopify store, it will be available in your dashboard and you can perform all the basic operations - <br>
						<br>
						•modifying product title, description, images
						•applying tags, collections or other meta information
						•hiding / unhiding from online store
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Can I disable the 'View on Amazon' button?
				</a>
				<div class="cd-faq-content">
					<p>
						Yes you can. Just add a tag called <span class="b">linkify-hidden</span> to any product you want. 'Add to cart' button will not be replaced with 'View on Amazon' button.<br>
						<br>
						You can also add <span class="b">Linkify-hidden</span> tag by default to all products you import from Amazon via Shopify. To do this simply, go to Dashboard --> Settings --> Default Values and add <span class="b">Linkify-hidden</span> in the Tags input box.<br>
						<br>
						Detailed instructions on how to add linkify-hidden tag can be found <a href="https://help.shopify.com/manual/apps/working-with-apps#uninstall-an-app" target="blank">here.</a>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
					How to add 'Linkify-hidden' tag?
				</a>
				<div class="cd-faq-content">
					<p>
						<span class="b"> Linkify-hidden </span>tag can be added via 2 methods: <br>
						<br>
						<span class="b">1. Via Linkify Dashboard</span><br>
						a. Login to Linkify Dashboard<br>
						b. Goto 'Settings' page<br>
						c. Click 'Default Values'<br>
						d. Add linkify-hidden tag in the Tags field<br>
						<br>
						All products which you now import from Amazon will have Linkify-hidden tag added to them.<br>
						<br>
						Image or Video to be uploaded------------------<br>
						<span class="b">2. Via Shopify Dashboard (for products already imported via Linkify)</span><br>
						a. In Shopify dashboard goto the product page where you want to apply Linkify-hidden tag<br>
						b. Look for Tags input section<br>
						c. Add Linkify-hidden tag<br>
						<br>
						Repeat for all products for which you do not want 'View on Amazon' button.
						<br>
						Image or Video to be uploaded------------------<br>               
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
					What happens when there is a theme change?
				</a>
				<div class="cd-faq-content">
					<p>
						We auto detect a theme change and add the relevant Linkify files to the new theme. You, however, have to manually insert the Linkify integration code as mentioned<a href="https://help.shopify.com/manual/apps/working-with-apps#uninstall-an-app" target="blank"> here</a>. Alternatively, you can email us at <span class="b">Support@linkify.freshdesk.com </span> and we will do it for you.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
					Can I have both 'Add to cart' and 'View on Amazon' buttons displayed together?
				</a>
				<div class="cd-faq-content">
					<p>
						Yes, you can have both the buttons displayed on the same page.<br>
						<br>
						Email us at <span class="b">support@linkify.freshdesk.com</span> for having both the buttons. We will add customized code for you to make it happen.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
				What is auto-tagging?</a>
				<div class="cd-faq-content">
					<p><br>
						Auto-tagging allows the stores to automatically add Shopify product <a href="https://Linkify.freshdesk.com/support/solutions/articles/24000020475-what-is-auto-tagging-" target="blank">tags </a>while importing products from Amazon. Tags are added based on the product information derived from Amazon.<br>
						<br>
						Users can select specific tags which need to be auto-added while importing the products.<br>
						<br>
						Example - if the users select Brand and ProductGroup as auto-tags while importing a<a href="https://www.amazon.com/Nike-Tanjun-Black-White-Running/dp/B00XWPXO3K/ref=sr_1_1?ie=UTF8&qid=1517213955&sr=8-1&keywords=nike+shoes" target="blank"> Nike Men's Tanjun Premium Shoe</a> then two product tags - 1. <span class="b">Nike</span> and 2.<span class="b"> Shoes </span> - will be auto added to the the product while importing it from Amazon to Shopify.<br>
						<br>
						Note:<br>
						<br>
						•Auto-tagging cannot be applied retrospectively to the products already imported before.<br>
						•If the tag information derived from Amazon is empty then the tag will not be added.<br>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
		</ul>
		<!-- cd-faq-group -->
		<ul id="affiliate" class="cd-faq-group">
			<li class="cd-faq-title">
				<h2>Amazon - Affiliates</h2>
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Who pays me - Linkify or Amazon Affiliate Network?
				</a>
				<div class="cd-faq-content">
					<p>
						When a user clicks on your affiliate link and purchases an item on Amazon, you will receive a commission for your referral. Your commission will be paid by Amazon affiliate network.<br>
						<br>
						What does this mean for you?<br>
						1. Keep 100% of your commissions. Because Linkify does not act as a "go between" between you and Amazon, you keep everything your refer!<br>
						2. Amazon approval required - You must be approved by Amazon to be eligible for receiving payments.<br>
						3. Linkify does not monitor your site - Linkify does not track your links nor do we act as a redirect between your site and Amazon. We do not perform analytics on your click-throughs, monitor your traffic or analyze your target market.You get all the stats in Amazon Affiliate Dashboard.<br>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
					Is Amazon Affiliate ID required?
				</a>
				<div class="cd-faq-content">
					<p>
						Yes, Amazon Affiliate ID is required.<br> <br>
						When a user on your website clicks an Amazon link and purchases a product on Amazon website, you will receive a commission for your referral. Your commission will be paid by Amazon affiliate network.<br>
						<br>
						Amazon ID is required for:<br>
						<br>
						1. Linkify to insert the ID in the Amazon product links on your website.<br>
						2. Amazon to track and attribute the sale to your account.<br>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">How can I get Amazon Affiliate ID?</a>
				<div class="cd-faq-content">
					<p>You need Amazon Affiliate ID to track and get sales commission from Amazon. To get Amazon Affiliate ID you need to join Amazon Affiliate Program - its free.<br>
						<br>
						Here is the link to getting started - https://affiliate-program.amazon.com<br>
						<br>
						Select your country specific Amazon Affiliate Program and signup. Once inside the dashboard you will get your Affiliate ID.<br>
						<br>
						image to be added-------------------------------<br>
						Lastly, save the Affiliate ID in the settings section of Linkify dashboard.<br><br>
						image to be added-------------------------------<br><br>
						Thereafter, all the sales generated will be credited to you.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">Which country specific Amazon Affiliate Programs does Linkify support?
				</a>
				<div class="cd-faq-content">
					<p>Currently, we support Amazon Affiliates for USA, UK, Canada, India, Germany, France, Spain, Italy, Mexico, Japan, Brazil and Australia. More countries coming soon.</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
					How much commission will I earn?
				</a>
				<div class="cd-faq-content">
					<p>
						The commissions you earn will vary depending on the country specific Affiliate Program and the purchased product.<br> <br>
						Please refer <a href="https://affiliate-program.amazon.com/help/operating/policies#Associates%20Program%20Fee%20Statement" target="blank">Associates Program Advertising Fee Schedule</a> for commission rates and rules applicable to you.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
					Do I need to add Amazon's affiliate disclosure policy?
				</a>
				<div class="cd-faq-content">
					<p>
						As Shopify store owners using Amazon Associates, you may be wondering if you need a disclaimer or a disclosure informing users about your use of Amazon Associates or if you need other legal agreements as well.<br>
						<br>
						First, Amazon does not require you to have a Privacy Policy. There is no mention of a Terms & Conditions agreement requirement. What’s Amazon really looking for? Proper disclosure as outlined in Amazon’s affiliate disclosure policy. <br>
						<br>
						You must clearly state the following on your site:<br>
						<br>
						<mark>[Insert your name] is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to [insert the applicable site name (myshopify.com)].</mark>
						<br>
						Our recommendation is to have the disclosure on every page. We like to be safe. You can easily do this by creating a new text widget in your sidebar or footer. Having said that, it may suffice to include the disclosure on a page located somewhere on your site - like the contact us page.<br>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
					Does Amazon allow dropshipping?
				</a>
				<div class="cd-faq-content">
					<p>
						To dropship via Amazon, you need to follow Amazon policies and terms. <br>
						<br>
						Please check the links below:<br>
						<br>
						1.<a href="https://sellercentral.amazon.com/gp/help/external/201808410?language=en-US&ref=mpbc_201808430_cont_201808410" target="blank"> Amazon Dropshipping Policy</a><br>
						2.<a href="https://www.amazon.com/gp/help/customer/display.html/ref=aw?ie=UTF8&nodeId=13819201" target="blank"> Amazon Prime Terms</a><br>
						<br>
						Amazon Prime isn't available for customers (dropshippers) who purchase products for the purpose of resale or use Amazon Prime to ship products to their customers or potential customers. Hence, you can't use prime products for dropshipping.<br>
						<br>
						We recommend drop-shipping to only those stores which already sell on Amazon and can use their inventory to fulfill orders from Shopify.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">
					How to verify my Amazon affiliate links are working correctly?
				</a>
				<div class="cd-faq-content">
					<p>
						You can verify your affiliate links using <a href="https://affiliate-program.amazon.com/home/tools/linkchecker?ac-ms-src=ac-nav" target="blank">Amazon Link Checker</a>, the free tool available in Amazon affiliate dashboard.<br>
						<br>
						1. Import a product via Linkify app<br>
						2. Go to the imported product page on your Shopify site<br>
						3. Click on<span class="b"> 'View on Amazon'</span> button<br>
						4. The Amazon product page which opens in a new tab will have<span class="b"> ?tag=yourAmazonTag-20</span> in the URL - this means your associate ID is embedded in the link and your will get credit for the sale.<br>
						4. Put the entire URL in the <a href="https://affiliate-program.amazon.com/home/tools/linkchecker?ac-ms-src=ac-nav" target="blank">Amazon link checker</a>. It will tell you whether the link is valid with your affiliate ID.<br>
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
		</ul>
		<!-- cd-faq-group -->
		<ul id="sync" class="cd-faq-group">
			<li class="cd-faq-title">
				<h2>Product-Sync</h2>
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">What is auto-sync?
				</a>
				<div class="cd-faq-content">
					<p>Auto-sync feature helps Shopify stores to automatically update product price and availability values to match Amazon so that the inventory and prices are always up to date.<br>
						<br>
						Linkify auto-syncs each product once in every 12 hours.<br>
						<br>
						Auto-sync is available for all users for free as we are running as<span class="b"> Welcome Offer </span>is going on.<br>
						<br>
						Once activated auto-sync will be applied to all the products present in the Linkify dashboard..
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">What are Auto-sync rules?	</a>
				<div class="cd-faq-content">
					<p>Linkify doesnt have any specific rules. It Syncs as per amazon products</p>
				</div>
				<!-- cd-faq-content -->
			</li>
		</ul>
		<ul id="markup" class="cd-faq-group">
			<li class="cd-faq-title">
				<h2>MarkUp Price</h2>
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">What is Markup Pricing?</a>
				<div class="cd-faq-content">
					<p>Markup Pricing allows you to setup pricing rules to add margin / markup to the products you import from Amazon. Linkify will multiply and/or add a fixed markup to the original Amazon price by the numbers you set in the Markup Settings page.<br>
						<br>
						On enabling Markup Pricing it will be applied to all new products imported via Linkify. If Auto-sync is activated the marked-up products will be updated as per your Markup Pricing rules. Existing products continue to work as before.<br>
						<br>
						Markup Pricing should only be applied to products for drop-shipping. Stores having Amazon affiliate only products should ignore this feature.
					</p>
				</div>
				<!-- cd-faq-content -->
			</li>
			<li>
				<a class="cd-faq-trigger" href="#0">How to apply Markup Pricing to existing products?</a>
				<div class="cd-faq-content">
					<p>On activating Markup Pricing it gets applied to all<span class="b"> new </span>products imported via Linkify. Existing products will be marked-uped every 12hours of products Sync </p>
				</div>
				<!-- cd-faq-content -->
			</li>
		</ul>
		<!-- cd-faq-group -->
	</div>
	<!-- cd-faq-items -->
	<a href="#0" class="cd-close-panel">Close</a>
</section>
@stop
@section('js')
<?= Html::script('frontend/js/jquery-2.1.1.js',[],IS_SECURE) ?>
<?= Html::script('frontend/js/jquery.mobile.custom.min.js',[],IS_SECURE) ?>
<?= Html::script('frontend/js/main.js',[],IS_SECURE) ?>
@stop